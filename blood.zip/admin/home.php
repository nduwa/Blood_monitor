<?php
include('plugins/top_header.php');
//if ($row_post['acc_mail'] == 1) { include('plugins/top_msg.php'); }
//include('plugins/top_tasks.php');
include('plugins/top_useraccount.php');
include('plugins/main_sidebar.php');

if(@$_GET['view']=="profile"){ include('pages/users/profile.php'); } // Calling to view user profile
if(@$_GET['view']=="Model"){ include('pages/models.php'); } // Calling to view models
if(@$_GET['view']=="user"){ include('pages/users/user.php'); } // Calling to view users
if(@$_GET['view']=="mailbox"){ include('pages/mailbox/mailbox.php'); } // Calling to view Messages
if(@$_GET['view']=="readmail"){ include('pages/mailbox/read-mail.php'); } // Calling to view Message content
if(@$_GET['view']=="teen_post"){ include('pages/UI/teen-posts.php'); } // Calling to view Teen User Posts
if(@$_GET['view']=="user_access"){ include('pages/UI/user_right.php'); } // Calling to view Teen User Posts
if(@$_GET['view']=="UserAccess"){ include('pages/UI/userAccess.php'); } // Calling to view  User Accesses
if(@$_GET['view']=="blood"){ include('pages/UI/region.php'); } // Calling to view the regional blood center
if(@$_GET['view']=="blood_dis"){ include('pages/UI/distributor.php'); } // Calling to view the regional blood center
if(@$_GET['view']=="pub"){ include('pages/UI/bloodStore.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="health"){ include('pages/UI/health_store.php'); } //Calling to view healthStore 


if(@$_GET['view']=="national"){ include('pages/UI/national_blood.php'); } // Calling to view the regional blood center
if(@$_GET['view']=="report"){ include('pages/UI/report.php'); } //Calling to view healthStore 
if(@$_GET['view']=="blood_report"){ include('pages/UI/store_report.php'); } //Calling to view healthStore
if(@$_GET['view']=="wast"){ include('pages/UI/wastage.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="health_detail"){ include('pages/UI/blood_report.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="used_blood"){ include('pages/UI/blood_used.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="wastage_blood"){ include('pages/UI/wastage_blood.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="health_store"){ include('pages/UI/health_store_report.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="rcbt_report"){ include('pages/UI/rcbt_store.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="list_health"){ include('pages/UI/health_list.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="ncbt_report_rcbt"){ include('pages/UI/ncbt_rcbt_report.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="rcbt_blood_report"){ include('pages/UI/ncbt_view_report.php'); } // Calling to view Teen bloodStore file
if(@$_GET['view']=="ncbt_health_report"){ include('pages/UI/ncbt_health_report.php'); } // Calling to view Teen bloodStore file

if(@$_GET['view']=="blood_type"){ include('pages/UI/bloodType.php'); } // Calling to view blood type file
if(@$_GET['view']=="utility"){ include('pages/UI/utility.php'); } // Calling to view blood utility file
if(@$_GET['view']=="privilege"){ include('pages/UI/privileges.php'); } // Calling to privilege
if(@$_GET['view']=="donors"){ include('pages/UI/donors.php'); } // Calling to view visitor
if(@$_GET['view']=="search"){ include('pages/UI/search.php'); } // Calling to view visitor



if(@$_GET['ADD']=="Model"){ include('pages/forms/models.php'); } // Calling Form to add models
if(@$_GET['ADD']=="user"){ include('pages/forms/user.php'); } // Calling Form to add models
if(@$_GET['ADD']=="donor"){ include('pages/forms/donor.php'); } // Calling Form to add new partner
if(@$_GET['ADD']=="Dona_up"){ include('pages/forms/donation.php'); } // Calling Form to add programs
if(@$_GET['ADD']=="bloodreduce"){ include('pages/forms/bloodreduce.php'); } // Calling Form to add bloodreduce
if(@$_GET['ADD']=="new_request"){ include('pages/forms/new_request.php'); } // Calling Form to add bloodreduce
if(@$_GET['ADD']=="bloodrequest"){ include('pages/forms/bloodrequest.php'); } // Calling Form to add testimony

if(@$_GET['ADD']=="pub"){ include('pages/forms/bloodStore.php'); } // Calling Form to add bloodStore
if(@$_GET['ADD']=="Don"){ include('pages/forms/update_don.php'); } // Calling Form to update the blood donor

include("plugins/footer.php"); ?>