<?php
session_start();
include 'connection.php';
/*===========================================
				the login part
============================================*/

if(isset($_POST["login"])) {
	$email = $_POST["email"];
	$passcode = md5($_POST["passcode"]);
	$status = 1;
	$sql = "SELECT * from users WHERE user_email = '" . $email . "' AND user_password = '" . $passcode . "'";
	$result = $conn->query($sql);
	echo $conn->error;
	$row = $result->fetch_assoc();
	if($result->num_rows) {
		if($row['user_status'] == 1){
			$_SESSION["teenUser_id"]	=	$row["user_email"];
			$url = "../home.php?view=Model";
		} else {
			$message = "Account doesn't have permission!";
			$url = "../index.php?msg=" . $message;
		}
	} else {
		$message = "Invalid Login";
		$url = "../index.php?msg=" . $message;
	}
	header('location: '.$url);
}

/*===========================================
				the login part
============================================*/

if(isset($_POST["reset_password"])) {
	$email = $_POST["email"];
	$phone = $_POST["phone"];
	$username = $_POST["username"];
	$new_passcode = md5($_POST["new_passcode"]);
	$status = 1;
	$sql = "SELECT * from users WHERE user_name = '".$username."' AND user_email = '" . $email . "' AND user_phone = '" . $phone . "'";
	$result = $conn->query($sql);
	if($result) {
		$sql_update = "UPDATE users SET user_password = '".$new_passcode."' WHERE user_name = '".$username."' AND user_email = '" . $email . "' AND user_phone = '" . $phone . "'";
		$result_update = $conn->query($sql_update);
		if($result_update){
			$message = "good and well!";
			$url = "../index.php?msg=" . $message;
		} else {
			$message = "Account doesn't have permission!";
			$url = "../forget_password.php?msg=" . $message;
		}
	} else {
		$message = "Wrong input data";
		$url = "../index.php?msg=" . $message;
	}
	header('location: '.$url);
}
/*===========================================
				the logout part
============================================*/
if(isset($_REQUEST['teen_logout'])){
	$_SESSION["teenUser_id"] = "";
	session_destroy();
	header("location: ../index.php");
}



/*================================================================================
								Insert Part
================================================================================*/



/*===========================================
				the Add new user part
============================================*/

if (isset($_POST['add_user'])) {
	$user_id = $_POST['username'];
	$name = $_POST['name'];
	$title = $_POST['user_title'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$level = $_POST['place_title'];
	$default_profile = "default_profile.png";
	$password = "blood";
	$passcode = md5($password);
	$status = 1;
	$sql = "INSERT INTO users VALUES (null, '$name', '$user_id', '$phone', '$email', '$passcode', '$default_profile', NOW(), '$title', '$level', '$status')";
	$result = $conn->query($sql);

	if ($result) {
		header("location: ../home.php?ADD=user&yeah&pass=".$password);	
	}
	else{
		echo $conn->error;
	}
}

/*===========================================
				Add model part
============================================*/
 if (isset($_POST['insert_info'])) {
 	$model = $_POST['Inspire_model'];
 	$teen = $_POST['teen_integrated'];
 	$challenge = $_POST['teen_challenge'];
 	$mission = $_POST['mission'];
 	$vision = $_POST['vision'];
 	$we_do = $_POST['work'];
 	$mentorship = $_POST['Mentorship'];
 	$empower = $_POST['Empowerment'];
 	$research = $_POST['research'];
 	$partnership = $_POST['partnership'];

 	$sql = "INSERT INTO about_teen (short_msg, teen_definition, what_we_do, our_vision, our_mission, mentorship, empowerment, research_advocacy, teen_challenge, partnership) VALUES ('$model', '$teen', '$we_do', '$vision', '$mission', '$mentorship', '$empower', '$research', '$challenge', '$partnership')";
 	$result = $conn->query($sql);

	if ($result) {
		header("location: ../home.php?ADD=Model&yeah");	
	}
	else{
		echo $conn->error;
	}
 }

/*===========================================
				Add model part
============================================*/
 if (isset($_POST['add_donor'])) {
 	$card = "BD".rand(0000,9999);
 	$fname = $_POST['fname'];
 	$lname = $_POST['lname'];
 	$email = $_POST['don_email'];
 	$phone = $_POST['don_phone'];
 	$address = $_POST['don_address'];
 	$blood = $_POST['blood_type'];
 	$collector = $_POST['collector'];

 	$sql = "INSERT INTO donors  VALUES (null,'$card', '$fname', '$lname', '$email', '$phone', '$address', '$blood','$collector', NOW(), NOW())";
 	$result = $conn->query($sql);

	if ($result) {
		header("location: ../home.php?view=donors&yeah");	
	}
	else{
		echo $conn->error;
	}
 }

/*===========================================
				new request
============================================*/
 if (isset($_POST['newrequest'])) {
 	$user = $_POST['username'];
 	$code = $_POST['Bloodcode'];
 	$type = $_POST['Bloodtype'];
 	$qnte = $_POST['Quantity'];
 	

 	$sql = "INSERT INTO message  VALUES (null, '$user', '$code', '$type', '$qnte', NOW(), NOW())";
 	$result = $conn->query($sql);

	if ($result) {
		header("location: ../home.php?view=donors&yeah");	
	}
	else{
		echo $conn->error;
	}
 }

/*===========================================
				Add New send_request part
============================================*/
if (isset($_POST['send_request'])) {
	$status = 0;
	$user = $_POST['username'];
	$code = $_POST['user_title'];
	$usetype = $_POST['usertype'];
	$type = $_POST['bl_type'];
	$qnte = $_POST['Quantity'];
	$serve = $_POST['serve'];
	$comment = $_POST['Comment'];
	$date = date('Y-m-d');

	$sql = "INSERT INTO bloodrequest VALUES(null, '$user', '$code', '$usetype', '$type', '$qnte', '$serve', '$comment', '$status', '$date')";
		$result = $conn->query($sql);
		if ($result) { $url = "../home.php?view=health&feed=done"; }
		else { $url = "../home.php?ADD=bloodrequest&error=" . $conn->error; }
	
	header('location: '.$url);
}
/*===========================================
				Add New serve blood part
============================================*/
if (isset($_POST['serve_blood'])) {
	$tid = $_POST['id'];
	$user = $_POST['username'];
	$code = $_POST['user_title'];
	$blood_type = $_POST['blood_type'];
	$type = $_POST['patient'];
	$qnte = $_POST['Quantity'];
	$comment = $_POST['Comment'];
	$date = date('Y-m-d');

	$sql_serve = "SELECT * FROM distributed_blood WHERE distributed_id = '$tid'";
	$result_serve = $conn->query($sql_serve);
	if ($result_serve->num_rows > 0) {
		$row_serve = $result_serve->fetch_assoc();
		$data = $row_serve['quantity'];

		$solution = $data - $qnte;

		$sql = "INSERT INTO served_blood VALUES(null, '$type', '$blood_type', '$qnte', '$comment', '$code', '$user',  '$date')";
			$result = $conn->query($sql);
			if ($result) {
				$sql_up_serve = "UPDATE distributed_blood SET quantity = '$solution' WHERE distributed_id = '$tid'";
				$result_up_serve = $conn->query($sql_up_serve);
				if ($result_up_serve) {
			 		$url = "../home.php?view=health&feed=done"; 
				}
				else { $url = "../home.php?ADD=bloodreduce&error=" . $conn->error; }
			}
			else { $url = "../home.php?ADD=bloodreduce&error=" . $conn->error; }
	}
			else { $url = "../home.php?ADD=bloodreduce&error=" . $conn->error; }


	header('location: '.$url);
}

/*=====================================================================================
				Add New Post part
======================================================================================*/
if (isset($_POST['new_post'])) {
 	$post = $_POST['post'];
 	$region = $_POST['regions'];
 	$longitude = $_POST['longitude'];
 	$latitude = $_POST['latitude'];
 	$sql_chk = "SELECT * FROM teen_posters WHERE post_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=teen_post&msg=available"; }
 	else {
 		$sql = "INSERT INTO teen_posters VALUES (NULL, '$post','$region')";
 		$result = $conn->query($sql);
 		if ($result) {
			$post_id = mysqli_insert_id($conn);
			$sql_cordone = "INSERT INTO tbl_cordinates VALUES(null, '$longitude','$latitude','$post_id')";
			$result_cordone = $conn->query($sql_cordone);
			if ($result_cordone) {
				$url = "../home.php?view=teen_post&msg=done";
			}else {
			$url = "../home.php?view=teen_post&msg=error";}
		}
		else {
			$url = "../home.php?view=teen_post&msg=error";
		}
		
 		}
 	header('location: '.$url);
}
/*=====================================================================================
				Add New Post part
======================================================================================*/
if (isset($_POST['new_level'])) {
 	$post = $_POST['post'];
 	$sql_chk = "SELECT * FROM places WHERE place_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=user_access&msg=available"; }
 	else {
 		$sql = "INSERT INTO places VALUES (NULL, '$post')";
 		$result = $conn->query($sql);
 		if ($result) {
 			$post_id = mysqli_insert_id($conn);
 			$sql_priv = "INSERT INTO user_privilegie(place_id) VALUES ('$post_id')";
 			$result_priv = $conn->query($sql_priv);
 			if ($result_priv) {
 				$url = "../home.php?view=user_access&msg=done";
 			}
 			else {
 				$url = "../home.php?view=user_access&msg=error";
 			}
 			
 		}
 		else{
 			$url = "../home.php?view=user_access&msg=error";
 		}
 	}
 	header('location: '.$url);
}


/*=====================================================================================
				Add New regional blood center part
======================================================================================*/
if (isset($_POST['new_region'])) {
 	$post = $_POST['post'];
 	$sql_chk = "SELECT * FROM regional WHERE reg_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=reg_blood&msg=available"; }
 	else {
 		$sql = "INSERT INTO regional VALUES (NULL, '$post')";
 		$result = $conn->query($sql);
 		if ($result) {
 				$url = "../home.php?view=reg_blood&msg=done";
 			}
 			else {
 				$url = "../home.php?view=reg_blood&msg=error";
				}	
 	}
 	header('location: '.$url);
}
/*=====================================================================================
				Add New blood type part
======================================================================================*/
if (isset($_POST['new_type'])) {
 	$post = $_POST['post'];
 	$type  ="BL".rand(0000,9999);
 	$sql_chk = "SELECT * FROM blood_type WHERE type_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=blood_type&msg=available"; }
 	else {
 		$sql = "INSERT INTO blood_type VALUES (NULL, '$post', '$type')";
 		$result = $conn->query($sql);
 		if ($result) {
 				$url = "../home.php?view=blood_type&msg=done";
 			}
 			else {
 				$url = "../home.php?view=blood_type&msg=error";
				}	
 	}
 	header('location: '.$url);
}
/*=====================================================================================
				Add New blood type part
======================================================================================*/
if (isset($_POST['utility'])) {
 	$post = $_POST['post'];
 	$sql_chk = "SELECT * FROM blood_utility WHERE type_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=utility&msg=available"; }
 	else {
 		$sql = "INSERT INTO blood_utility VALUES (NULL, '$post')";
 		$result = $conn->query($sql);
 		if ($result) {
 				$url = "../home.php?view=utility&msg=done";
 			}
 			else {
 				$url = "../home.php?view=utility&msg=error";
				}	
 	}
 	header('location: '.$url);
}



/*===========================================
				Add New Publication part
============================================*/
if (isset($_POST['newpub'])) {
	$season = $_POST['season'];
	$user = $_POST['username'];
	$code = $_POST['userid'];
	$type = $_POST['Bloodtype'];
	$use = $_POST['utile'];
	$qnte  = $_POST['post'];
	$reason = $_POST['reason'];

	if ($use == 1) {
		$fetch_qty = "SELECT * FROM bloodstore WHERE username = '$user' AND bl_type_id = '$type'";
		$data = $conn->query($fetch_qty);

		if ($data->num_rows > 0) {
			$value = $data->fetch_assoc();
			$record = $value['bl_qntes'];
			$sum = $qnte + $record;	

			$sql = "UPDATE bloodstore SET  bl_qntes='$sum' WHERE username = '$user' AND bl_type_id = '$type'";
			$result = $conn->query($sql);
			if ($result) {
				

				$sql_backup = "INSERT INTO tbl_bloodstore_backup VALUES(null, '$season', '$user', '$code', '$type', '$use', '$qnte', '$reason',NOW(), NOW())";
				$result_backup = $conn->query($sql_backup);
				if ($result_backup) { 
					$sql_sum = "SELECT * FROM bloodstore WHERE username = '$user'";
					$result_sum = $conn->query($sql_sum);
					$summation = 0;
					while ($row_sum = $result_sum->fetch_assoc()) {
						$out = $row_sum['bl_qntes'];
                         $summation+=$out;
					}
					if ($summation > 0 ) {
						$sql_data = "INSERT INTO tbl_summation VALUES(null,'$user','$summation',NOW())";
						$result_data = $conn->query($sql_data);
						if ($result_data) {
							$url = "../home.php?view=pub&feed=done"; 
						}
					}
				}
			}
		}
		else {
			$sql_insert = "INSERT INTO bloodstore VALUES(null, '$user', '$code', '$type', '$use', '$qnte',NOW(), NOW())";
			$result_insert = $conn->query($sql_insert);
			if ($result_insert) { 
				$sql_backup = "INSERT INTO tbl_bloodstore_backup VALUES(null, '$season', '$user', '$code', '$type', '$use', '$qnte', '$reason',NOW(), NOW())";
				$result_backup = $conn->query($sql_backup);
				if ($result_backup) { 
					$sql_sum = "SELECT * FROM bloodstore WHERE username = '$user'";
					$result_sum = $conn->query($sql_sum);
					$summation = 0;
					while ($row_sum = $result_sum->fetch_assoc()) {
						$out = $row_sum['bl_qntes'];
                         $summation+=$out;
					}
					if ($summation > 0 ) {
						$sql_data = "INSERT INTO tbl_summation VALUES(null,'$user','$summation',NOW())";
						$result_data = $conn->query($sql_data);
						if ($result_data) {
							$url = "../home.php?view=pub&feed=done"; 
						}
					}
				}
			}
		}
	
	}else{
		$sql_backup = "INSERT INTO tbl_bloodstore_backup VALUES(null, '$season', '$user', '$code', '$type', '$use', '$qnte', '$reason',NOW(), NOW())";
			$result_backup = $conn->query($sql_backup);
			if ($result_backup) { 
				$url = "../home.php?view=pub&feed=done"; 
			}
	}
    
	
	
		header('location: '.$url);
	}
	
/*===========================================
				Update User Settings part
============================================*/
if (isset($_POST['update_set'])) {
	$names = $_POST['names'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$new_code = $_POST['new_code'];
	$pass = md5($_POST['passcode']);

	$sql_chk = "SELECT * FROM users WHERE user_email = '".$_SESSION['teenUser_id']."' AND user_password = '$pass'";
	$result_chk = $conn->query($sql_chk);
	if($result_chk->num_rows > 0){
		$row = $result_chk->fetch_assoc();
		$id = $row['user_id'];
		$profile  = $_FILES['profile']['name'];
		

		if (!empty($profile)) { // Checking if there is an uploaded profile

			$file_ext = substr($profile, strripos($profile, '.'));
			$ran = "teen_pro" . rand() . $file_ext;
			$target = "../dist/img/" . $ran;

			if (move_uploaded_file($_FILES['profile']['tmp_name'], $target)) { // Uploading profile into dist/img folder
				$adds = ", profile = '$ran'";
				if ($row['profile'] != "default_profile.png") {
					unlink("../dist/img/" . $row['proflie']);
				}
			}// ./Uploading profile into dst/img folder
			else{// there is an error in uploading
				echo "sorry there is an error!";
			}// ./there is an error in uploading

		}// ./ Checking if there is an uploaded profile
		else {
			$adds = "";
		}

		if (!empty($new_code)) {
			$new_code = md5($new_code);
			$sql = "UPDATE users SET user_name = '$names', user_phone = '$phone', user_email = '$email', user_password = '$new_code'" . $adds . " WHERE user_id = '$id'";
		}
		else {
			$sql = "UPDATE users SET user_name = '$names', user_phone = '$phone', user_email = '$email' " . $adds . " WHERE user_id = '$id'";
		}
		$result = $conn->query($sql);
		if ($result) {
			$_SESSION["teenUser_id"] = $email;
			$url = "../home.php?view=profile&feed=done";
		}
		else{
			echo "Error: ".$conn->error;
		}
	}
	else{
		$url = "../home.php?view=profile&feed=Password Incorrect";
	}
	header('location: '.$url);
}



/*===========================================
				Update User Status
============================================*/
if (isset($_GET['usr_id']) && isset($_GET['act'])) {
	$usr = $_GET['usr_id'];
	$action = $_GET['act'];
	$sql = "UPDATE users SET user_status = '$action' WHERE user_id = '$usr'";
	$result = $conn->query($sql);
	if ($result) {
		$url = "../home.php?view=user&done";
	}
	else {
		$url = "../home.php?view=user&error";
	}
	header('location: '.$url);
}
/*===========================================
				Update User place
============================================*/
if (isset($_GET['usr_adm']) && isset($_GET['acts'])) {
	$usr = $_GET['usr_adm'];
	$action = $_GET['acts'];
	$sql = "UPDATE users SET user_place = '$action' WHERE user_id = '$usr'";
	$result = $conn->query($sql);
	if ($result) {
		$url = "../home.php?view=user&done";
	}
	else {
		$url = "../home.php?view=user&error";
	}
	header('location: '.$url);
}

/*===================================================================
				Update User Status Ecception Part
=====================================================================*/
if (isset($_GET['us_nw']) && isset($_GET['act'])) {
	echo "hhhh";
	$usr = $_GET['us_nw'];
	$action = $_GET['act'];
	$sql = "UPDATE users SET user_status = '$action' WHERE user_id = '$usr'";
	$result = $conn->query($sql);
	if ($result) {
		$url = "../home.php?view=user&us_nw&done";
	}
	else {
		$url = "../home.php?view=user&us_nw&error";
	}
	header('location: '.$url);
}

/*===========================================
				Update model part
============================================*/
 if (isset($_POST['update_info'])) {
 	$model = $_POST['Inspire_model'];
 	$teen = $_POST['teen_integrated'];
 	$challenge = $_POST['teen_challenge'];
 	$mission = $_POST['mission'];
 	$vision = $_POST['vision'];
 	$we_do = $_POST['work'];
 	$sql = "UPDATE about_teen SET short_msg = '$model', teen_definition = '$teen', what_we_do = '$we_do', our_vision = '$vision', our_mission = '$mission'";
 	$result = $conn->query($sql);

	if ($result) {
		header("location: ../home.php?ADD=Model&yeah");	
	}
	else{
		echo $conn->error;
	}
 }

/*===========================================
				Update Post part
============================================*/
if (isset($_REQUEST['update_post'])) {
 	$post = $_REQUEST['post'];
 	$pid = $_REQUEST['update_post'];
 	$sql_chk = "SELECT * FROM teen_posters WHERE post_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=teen_post&msg=available"; }
 	else {
 		$sql = "UPDATE teen_posters SET post_name = '$post' WHERE post_id = '$pid'";
 		$result = $conn->query($sql);
 		if ($result) {
 			$url = "../home.php?view=teen_post&msg=done";
 		}
 		else{
 			$url = "../home.php?view=teen_post&msg=error";
 		}
 	}
 	header('location: '.$url);
}

/*===========================================
				Update the distributor as Hospital or clinics part
============================================*/
if (isset($_REQUEST['update_place'])) {
 	$post = $_REQUEST['post'];
 	$pid = $_REQUEST['update_place'];
 	$sql_chk = "SELECT * FROM place WHERE place_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=user_access&msg=available"; }
 	else {
 		$sql = "UPDATE place SET place_name = '$post' WHERE place_id = '$pid'";
 		$result = $conn->query($sql);
 		if ($result) {
 			$url = "../home.php?view=user_access&msg=done";
 		}
 		else{
 			$url = "../home.php?view=user_access&msg=error";
 		}
 	}
 	header('location: '.$url);
}
/*===========================================
				Update regional blood center part
============================================*/
if (isset($_REQUEST['update_region'])) {
 	$post = $_REQUEST['post'];
 	$pid = $_REQUEST['update_region'];
 	$sql_chk = "SELECT * FROM regional WHERE reg_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=reg_blood&msg=available"; }
 	else {
 		$sql = "UPDATE regional SET reg_name = '$post' WHERE reg_id = '$pid'";
 		$result = $conn->query($sql);
 		if ($result) {
 			$url = "../home.php?view=reg_blood&msg=done";
 		}
 		else{
 			$url = "../home.php?view=reg_blood&msg=error";
 		}
 	}
 	header('location: '.$url);
}
/*===========================================
				Update blood type part
============================================*/
if (isset($_REQUEST['update_type'])) {
 	$post = $_REQUEST['post'];
 	$pid = $_REQUEST['update_type'];
 	$sql_chk = "SELECT * FROM blood_type WHERE type_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=blood_type&msg=available"; }
 	else {
 		$sql = "UPDATE blood_type SET type_name = '$post' WHERE type_id = '$pid'";
 		$result = $conn->query($sql);
 		if ($result) {
 			$url = "../home.php?view=blood_type&msg=done";
 		}
/*===========================================
				Update blood utility part
============================================*/
if (isset($_REQUEST['utility_update'])) {
 	$post = $_REQUEST['post'];
 	$pid = $_REQUEST['utility_update'];
 	$sql_chk = "SELECT * FROM blood_utility WHERE utility_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=utility&msg=available"; }
 	else {
 		$sql = "UPDATE blood_utility SET utility_name = '$post' WHERE utility_id = '$pid'";
 		$result = $conn->query($sql);
 		if ($result) {
 			$url = "../home.php?view=utility&msg=done";
 		}
 		else{
 			$url = "../home.php?view=utility&msg=error";
 		}
 	}
 	header('location: '.$url);
}
 		else{
 			$url = "../home.php?view=blood_type&msg=error";
 		}
 	}
 	header('location: '.$url);
}
/*===========================================
				Update blood type part
============================================*/
if (isset($_REQUEST['update_type'])) {
 	$post = $_REQUEST['post'];
 	$pid = $_REQUEST['update_type'];
 	$sql_chk = "SELECT * FROM blood_type WHERE type_name = '$post'";
 	$result_chk = $conn->query($sql_chk);
 	if ($result_chk->num_rows > 0) { $url = "../home.php?view=blood_type&msg=available"; }
 	else {
 		$sql = "UPDATE blood_type SET type_name = '$post' WHERE type_id = '$pid'";
 		$result = $conn->query($sql);
 		if ($result) {
 			$url = "../home.php?view=blood_type&msg=done";
 		}
 		else{
 			$url = "../home.php?view=blood_type&msg=error";
 		}
 	}
 	header('location: '.$url);
}
/*===========================================
				Update About_Teen Status part
============================================*/
if (isset($_REQUEST['abt_st'])) {
 	$title = $_REQUEST['abt_st'];
 	$status = $_REQUEST['todo'];
 	$sql = "UPDATE about_teen SET " .$title. " = '$status'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=Model&msg=done";
	}
	else{
		$url = "../home.php?view=Model&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				UPDATE Donor part
============================================*/
if (isset($_POST['update_donor'])) {
	$colle = $_POST['colle_name'];
	$card = $_POST['card'];
 	$fname = $_POST['fname'];
 	$lname = $_POST['lname'];
 	$email = $_POST['don_email'];
 	$phone = $_POST['don_phone'];
 	$address = $_POST['don_address'];
 	$blood = $_POST['blood_type'];
 	$site = $_POST['site'];
 	$donate = $_POST['donate'];
 	$collector = $_POST['collector'];
	$id = $_POST['update_donor'];
	$sql =  "INSERT INTO donors  VALUES (null,'$card', '$colle', '$fname', '$lname', '$email', '$phone', '$address', '$blood','$site','$donate','$collector', NOW(), NOW())";
	$result = $conn->query($sql);
	if ($result) { $url = "../home.php?view=donors&feed=done"; }
	else { $url = "../home.php?ADD=Dona_up&error=" . $conn->error; }
 	header('location: '.$url);
}

/*===========================================
				UPDATE request part
============================================*/
if (isset($_POST['update_request'])) {
	$status = 1;
	$guide = $_POST['bl_id'];
	$user = $_POST['bl_user_title'];
	$code = $_POST['user_title'];
	$usetype = $_POST['blood_id'];
	$type = $_POST['serve'];

	$date = date('Y-m-d');
	
	$sql_send = "SELECT * FROM bloodstore WHERE username = '$code' AND bl_type_id = '$guide'";
	$result_send = $conn->query($sql_send);
	if ($result_send->num_rows > 0) {
		$row_send = $result_send->fetch_assoc();
		$calculas = $row_send['bl_qntes'];

		$insert = $calculas - $type;
		

		$sql_request = "SELECT * FROM distributed_blood WHERE request_id = '$user' AND blood_id = '$guide'";
		$result_request = $conn->query($sql_request);
		if ($result_request->num_rows > 0) {
			$row_request = $result_request->fetch_assoc();
			$cal_request = $row_request['quantity'];

			$insert_request = $cal_request + $type;

			$sql = "UPDATE distributed_blood SET quantity = '$insert_request' WHERE request_id = '$user' AND blood_id = '$guide'";
			$result = $conn->query($sql);
			if ($result) { 
				$sql_dis_backup = "INSERT INTO tbl_distributed_blood_backup VALUES(null, '$user', '$code', '$usetype', '$type', '$date')";
				$result_dis_backup = $conn->query($sql_dis_backup);
				if ($result_dis_backup) {
					$sql_up = "UPDATE bloodstore SET bl_qntes = '$insert' WHERE username = '$code' AND bl_type_id = '$guide'";
					$result_up = $conn->query($sql_up);
					if ($result_up) {
						$sql_up_status = "UPDATE bloodrequest SET bl_status = '$status' WHERE  served_quantity = '$user' AND  bl_type = '$guide'";
						$result_up_status = $conn->query($sql_up_status);
						if ($result_up_status) {
						$sql_sum = "SELECT * FROM tbl_summation WHERE location = '$code'";
							$result_sum = $conn->query($sql_sum);
							$row_sum = $result_sum->fetch_assoc();
								$out = $row_sum['quantity'];

								$reduction = $out - $type;
							
							if ($result_sum->num_rows > 0 ) {
								$sql_data = "UPDATE tbl_summation SET quantity = '$reduction' WHERE location = '$code'";
								$result_data = $conn->query($sql_data);
								if ($result_data) {
									$url = "../home.php?view=pub&feed=done"; 
								}
							}
						}
						 else { $url = "../home.php?ADD=mailbox&error=update status" . $conn->error; }
					}
					else { $url = "../home.php?ADD=mailbox&error= update store" . $conn->error; }
				}else { $url = "../home.php?ADD=mailbox&error= backup not inserted" . $conn->error; }
	}
			else { $url = "../home.php?ADD=mailbox&error=update" . $conn->error; }
		}
		else{
			$sql = "INSERT INTO distributed_blood VALUES(null, '$user', '$code', '$usetype', '$type', '$date')";
			$result = $conn->query($sql);
			if ($result) {
				$sql_dis_backup = "INSERT INTO tbl_distributed_blood_backup VALUES(null, '$user', '$code', '$usetype', '$type', '$date')";
				$result_dis_backup = $conn->query($sql_dis_backup);
				if ($result_dis_backup) {

					$sql_up = "UPDATE bloodstore SET bl_qntes = '$insert' WHERE username = '$code' AND bl_type_id = '$guide'";
					$result_up = $conn->query($sql_up);
					if ($result_up) {
						$sql_up_status = "UPDATE bloodrequest SET bl_status = '$status' WHERE served_quantity = '$user' AND  bl_type = '$guide'";
						$result_up_status = $conn->query($sql_up_status);
						if ($result_up_status) {
							$sql_sum = "SELECT * FROM tbl_summation WHERE location = '$code'";
								$result_sum = $conn->query($sql_sum);
								$row_sum = $result_sum->fetch_assoc();
									$out = $row_sum['quantity'];

									$reduction = $out - $type;
								
								if ($result_sum->num_rows > 0 ) {
									$sql_data = "UPDATE tbl_summation SET quantity = '$reduction' WHERE location = '$code'";
									$result_data = $conn->query($sql_data);
									if ($result_data) {
										$url = "../home.php?view=pub&feed=done"; 
									}
								}
						}
						 else { $url = "../home.php?ADD=mailbox&error=update status" . $conn->error; }
					}
					else { $url = "../home.php?ADD=mailbox&error=update store" . $conn->error; }
				}else { $url = "../home.php?ADD=mailbox&error= not insert backup" . $conn->error; }
		}
			else { $url = "../home.php?ADD=mailbox&error= insert disbu" . $conn->error; }
		}

}		else {
	
 $url = "../home.php?ADD=mailbox&error=" . $msg; 
}
	header('location: '.$url);
}



/*===========================================
				Update E-Mail Status part
============================================*/
if (isset($_REQUEST['readmail'])) {
 	$status = 1;
 	$id = $_REQUEST['readmail'];
 	$sql = "UPDATE message SET msg_status = '$status' WHERE msg_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=readmail&id=".$id;
	}
	else{
		$url = "#";
	}
 	header('location: '.$url);
}



/*===========================================
				Update Privileges Status part
============================================*/
if (isset($_REQUEST['privilege'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['privilege'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE teen_privileges SET ".$col." = '$status' WHERE post_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=privilege&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=privilege&id=".$poste."&error";
	}
 	header('location: '.$url);
}

/*===========================================
				Update user access part
============================================*/
if (isset($_REQUEST['usr_acc'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['usr_acc'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE teen_privileges SET ".$col." = '$status' WHERE post_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=privilege&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=privilege&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				Update user access part
============================================*/
if (isset($_REQUEST['user_acc'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['user_acc'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				Update additional part
============================================*/
if (isset($_REQUEST['additional'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['additional'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				Update blood model part
============================================*/
if (isset($_REQUEST['model_act'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['model_act'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				Update blood type part
============================================*/
if (isset($_REQUEST['type_act'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['type_act'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				view users privilege part
============================================*/
if (isset($_REQUEST['userView'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['userView'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				view users privilege part
============================================*/
if (isset($_REQUEST['useright'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['useright'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				view the blood location part
============================================*/
if (isset($_REQUEST['location'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['location'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				view the blood location part
============================================*/
if (isset($_REQUEST['locationView'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['locationView'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the blood region quantity part
============================================*/
if (isset($_REQUEST['region'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['region'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the blood Accessregion quantity part
============================================*/
if (isset($_REQUEST['Accessregion'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['Accessregion'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the blood AccessNation quantity part
============================================*/
if (isset($_REQUEST['AccessNation'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['AccessNation'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the blood utilityutility part
============================================*/
if (isset($_REQUEST['utility'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['utility'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the access on blood utility part
============================================*/
if (isset($_REQUEST['utilityAccess'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['utilityAccess'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the access on blood donorDonorAccess part
============================================*/
if (isset($_REQUEST['DonorAccess'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['DonorAccess'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the access on blood requestrequestAccess part
============================================*/
if (isset($_REQUEST['requestAccess'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['requestAccess'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the access on blood Store part
============================================*/
if (isset($_REQUEST['StoreAccess'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['StoreAccess'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
	view the access on healthHealthAccess blood Store part
============================================*/
if (isset($_REQUEST['HealthAccess'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['HealthAccess'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}
/*===========================================
				Update additional new user part
============================================*/
if (isset($_REQUEST['privilege'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['privilege'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}

/*===========================================
				Update additional new user part
============================================*/
if (isset($_REQUEST['Levels'])) {
 	$status = $_REQUEST['status'];
 	$col = $_REQUEST['Levels'];
 	$poste = $_REQUEST['poste'];
 	$sql = "UPDATE user_privilegie SET ".$col." = '$status' WHERE place_id = '$poste'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=UserAccess&id=".$poste."&done";
	}
	else{
		$url = "../home.php?view=UserAccess&id=".$poste."&error";
	}
 	header('location: '.$url);
}


/*================================================================================
								Delete Part
================================================================================*/


/*===========================================
				Delete Publication part
============================================*/
if (isset($_REQUEST['pudel'])) {
 	$name = $_REQUEST['file'];
 	$id = $_REQUEST['pudel'];
 	$sql = "DELETE FROM publication WHERE pub_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
 		unlink('../files/'.$name);
		$url = "../home.php?view=pub&msg=done";
	}
	else{
		$url = "../home.php?view=pub&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				Delete Instrument part
============================================*/
if (isset($_REQUEST['indel'])) {
 	$name = $_REQUEST['file'];
 	$id = $_REQUEST['indel'];
 	$sql = "DELETE FROM instrument WHERE inside = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
 		unlink('../files/'.$name);
		$url = "../home.php?view=instrument&msg=done";
	}
	else{
		$url = "../home.php?view=instrument&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				Delete Partner part
============================================*/
if (isset($_REQUEST['partel'])) {
 	$name = $_REQUEST['logo'];
 	$id = $_REQUEST['partel'];
 	$sql = "DELETE FROM partner WHERE part_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
 		unlink('../dist/img/'.$name);
		$url = "../home.php?view=partner&msg=done";
	}
	else{
		$url = "../home.php?view=partner&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				Delete Program part
============================================*/
if (isset($_REQUEST['prodel'])) {
 	$id = $_REQUEST['prodel'];
 	$sql = "DELETE FROM program WHERE pro_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
		$url = "../home.php?view=program&msg=done";
	}
	else{
		$url = "../home.php?view=program&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				Delete Slideshow part
============================================*/
if (isset($_REQUEST['slidel'])) {
 	$id = $_REQUEST['slidel'];
 	$name = $_REQUEST['img'];
 	$sql = "DELETE FROM slideshow WHERE slide_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
 		unlink('../images/'.$name);
		$url = "../home.php?view=slideshow&msg=done";
	}
	else{
		$url = "../home.php?view=slideshow&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				Delete Gallery Image part
============================================*/
if (isset($_REQUEST['galledel'])) {
 	$id = $_REQUEST['galledel'];
 	$name = $_REQUEST['img'];
 	$sql = "DELETE FROM gallery WHERE gallery_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
 		unlink('../images/'.$name);
		$url = "../home.php?view=gallery&msg=done";
	}
	else{
		$url = "../home.php?view=gallery&msg=error";
	}
 	header('location: '.$url);
}

/*===========================================
				Delete Testimony part
============================================*/
if (isset($_REQUEST['tedel'])) {
 	$name = $_REQUEST['file'];
 	$id = $_REQUEST['tedel'];
 	$sql = "DELETE FROM testimony WHERE test_id = '$id'";
 	$result = $conn->query($sql);
 	if ($result) {
 		unlink('../images/'.$name);
		$url = "../home.php?view=testimony&msg=done";
	}
	else{
		$url = "../home.php?view=testimony&msg=error";
	}
 	header('location: '.$url);
}

?>