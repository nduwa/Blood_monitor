<?php
$host = "localhost";
$user = "root";
$password = "";
$dbase = "lifeserveblood";
$conn = new mysqli($host, $user, $password, $dbase);
if ($conn->connect_error) die ($conn->connect_error);
?>