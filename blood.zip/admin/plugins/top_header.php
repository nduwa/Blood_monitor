<?php
session_start();
include('php/connection.php');
if(!isset($_SESSION["teenUser_id"])){ header('location: index.php');  } // checking for login access
$sql_user = "SELECT * FROM users INNER JOIN teen_posters ON users.user_title = teen_posters.post_id WHERE users.user_email = '" . $_SESSION["teenUser_id"] . "'";
$result_user =  $conn->query($sql_user);
$row_user = $result_user->fetch_assoc();
$teen_id = $row_user['user_id'];
$place = $row_user['user_place'];
$user_post = $row_user['user_title'];
$sql_post = "SELECT * FROM teen_privileges WHERE post_id = '$user_post'";
$result_post = $conn->query($sql_post);
$row_post = $result_post->fetch_assoc();
$sql = "SELECT * FROM user_privilegie WHERE place_id = '$place'";
$result = $conn->query($sql);
$rows = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Blood Monitor System</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="library/bootstrap/css/bootstrap.min.css">
  <!-- bootstrap wysihtml5 - text editor -->
<!--                         <link rel="stylesheet" href="library/bootstrap/css/bootstrap-responsive.min.css">
 -->  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="library/bootstrap/css/bootstrap3-wysihtml5.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="library/bootstrap/css/dataTables.bootstrap.min.css">

  <link rel="stylesheet" href="library/bootstrap/css/DT_bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="library/font-awesome/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="library/css/AdminLTE.min.css">
  <link rel="stylesheet" href="library/css/skins/_all-skins.min.css">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="home.php?view=Model" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="dist/img/logo.jpg" width="80%" /></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>

      </a>

                  
         <span  style="margin-left: 35%; margin-top: 1%; font-size: 2em; font-style: bold;">Blood Monitor System </span>       

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
