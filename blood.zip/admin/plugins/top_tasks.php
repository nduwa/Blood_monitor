          <?php
            $state = 0;
            //Tasks for Table User
            $task_user_sql = "SELECT * FROM users WHERE user_status = '$state' ORDER BY user_id DESC";
            $task_user_result = $conn->query($task_user_sql);

            //Tasks for Table Events
            $task_ev_sql = "SELECT * FROM events WHERE event_status = '$state' ORDER BY event_id DESC";
            $task_ev_result = $conn->query($task_ev_sql);

            //Tasks for Table Partner
            $task_part_sql = "SELECT * FROM partner WHERE part_status = '$state' ORDER BY part_id DESC";
            $task_part_result = $conn->query($task_part_sql);

            

            //Tasks for Table Testimony
            $task_test_sql = "SELECT * FROM testimony WHERE test_status = '$state' ORDER BY test_id DESC";
            $task_test_result = $conn->query($task_test_sql);

            @$task_num = $task_user_result->num_rows + $task_ev_result->num_rows + $task_part_result->num_rows + $task_slide_result->num_rows + $task_test_result->num_rows;
          ?>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger"><?php echo $task_num; ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have <?php echo $task_num; ?> tasks</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- New User Task item -->
                    <a href="home.php?view=user&newu">
                        <i class="fa fa-users text-aqua"></i>
                        <?php echo $task_user_result->num_rows; ?> New Users
                    </a>
                  </li>
                  <!-- end New Users task item -->

                  <li><!-- New Events Task item -->
                    <a href="home.php?view=event&nw">
                        <i class="fa fa-globe text-green"></i>
                        <?php echo $task_ev_result->num_rows; ?> New Events
                    </a>
                  </li>
                  <!-- end new events task item -->

                  <li><!-- New Partner Task item -->
                    <a href="home.php?view=partner&nw">
                        <i class="fa fa-users text-red"></i>
                        <?php echo $task_part_result->num_rows; ?> New Partner
                    </a>
                  </li>
                  <!-- end partner task item -->


                  <li><!-- New Testimony Task item -->
                    <a href="home.php?view=testimony">
                        <i class="fa fa-heart text-yellow"></i>
                        <?php echo $task_test_result->num_rows; ?> New Testimony
                    </a>
                  </li>
                  <!-- end New testimony task item -->
                </ul>
              </li>
            </ul>
          </li>
          
          <!-- User Account: style can be found in dropdown.less -->