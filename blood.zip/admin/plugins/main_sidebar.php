  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
    
      <!-- search form -->
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <!--         navigation menus       -->
        <li>
          <a href="home.php?view=Model">
            <i class="fa fa-cog"></i> Blood Transfusion Models</a>
          </a>
        </li>
        <?php if ($rows['view_location'] == 1)  { ?>
        <li>
          <a href="home.php?view=teen_post">
            <i class="fa fa-cogs"></i> <span>Blood Distributor Location</span>
          </a>
        </li>
        <?php } ?>
          <?php if ($rows['user_right'] == 1)  { ?>
        <li>
          <a href="home.php?view=user_access">
            <i class="fa fa-cogs"></i> <span>User Right</span>
          </a>
        </li>
        <?php } ?>

        <li>
          <a href="home.php?view=blood_type">
            <i class="fa fa-cogs"></i> <span>Type of Blood</span>
          </a>
        </li>

         <?php if ($rows['acc_utility'] == 1)  { ?>
        <li>
          <a href="home.php?view=utility">
            <i class="fa fa-cogs"></i> <span>Blood Utility</span>
          </a>
        </li>
        <?php } ?>

         <?php if ($rows['acc_nation'] == 1)  { ?>
        <li>
          <a href="home.php?view=national">
            <i class="fa fa-cogs"></i> <span>View Blood Reports </span>
          </a>
        </li>
        <?php } ?>

         <?php if ($rows['act_region'] == 1)  { ?>
        <li>
          <a href="home.php?view=blood">
            <i class="fa fa-cogs"></i> <span>View RCBT Store</span>
          </a>
        </li>
        <?php } ?>

       

         <?php if ($rows['acc_region'] == 1)  { ?>
        <li>
          <a href="home.php?view=blood_dis">
            <i class="fa fa-users"></i> <span>View Health Store</span>
          </a>
        </li>

         <?php } if ($rows['user_view'] == 1) { ?>
        <li>
          <a href="home.php?view=user">
            <i class="fa fa-users"></i> <span>System users</span>
          </a>
        </li>
        
        <?php } ?>
         <?php if ($rows['acc_donor'] == 1)  { ?>
        <li>
          <a href="home.php?view=donors">
            <i class="fa fa-users"></i> <span>Blood Donors</span>
          </a>
        </li>
        <?php } ?>

        <?php if ($rows['acc_request'] == 1)  { ?>
        <li>
          <a href="home.php?view=mailbox">
            <i class="fa fa-envelope"></i> <span>Blood Request </span>
          </a>
        </li>
        <?php } ?>

        <?php  if ($rows['acc_bloodstore'] == 1)  { ?>
        <li>
          <a href="home.php?view=pub">
            <i class="fa fa-envelope"></i> <span>Blood Stores </span>
          </a>
        </li>
        <?php } ?>
        <?php  if ($rows['acc_bloodstore'] == 1)  { ?>
        <li>
          <a href="home.php?view=used_blood">
            <i class="fa fa-envelope"></i> <span>Blood Report </span>
          </a>
        </li>
        <?php } ?>
      <?php  if ($rows['acc_heathstore'] == 1)  { ?>
        <li>
          <a href="home.php?view=health">
            <i class="fa fa-envelope"></i> <span>Health Store </span>
          </a>
        </li>
        
        <?php } ?>
        <?php  if ($rows['acc_heathstore'] == 1)  { ?>
        <li>
          <a href="home.php?view=report">
            <i class="fa fa-envelope"></i> <span>Health Report </span>
          </a>
        </li>
        <?php } ?>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

   <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header text-center">
      <h2>
        <span class="badge badge-info" style="  font-size: 0.7em;"><?php echo $row_user['post_name']; ?> </span>  
        <?php 
          $sql = "SELECT * FROM about_teen";
          $result = $conn->query($sql);
          $row = $result->fetch_assoc();
        ?><br>
        <small><i>"<?php echo $row['short_msg']; ?>"</i></small>
      </h2>
      <ol class="breadcrumb">
        <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Admin</li>
      </ol>
    </section>
