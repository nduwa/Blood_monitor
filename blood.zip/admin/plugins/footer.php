
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version 1 </b> Blood Monitor  
    </div>
    <strong>Copyright &copy;Blood Monitor Application.</strong> All rights
    reserved.
  </footer>


<!-- jQuery 3 -->
<script src="library/jquery/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="library/bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="library/js/adminlte.min.js"></script>

<script src="library/js/modernizr-2.6.2-respond-1.1.0.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="library/bootstrap/js/bootstrap3-wysihtml5.all.min.js"></script>
<!-- DataTables -->
<script src="library/js/jquery.dataTables.min.js"></script>
<script src="library/bootstrap/js/dataTables.bootstrap.min.js"></script>


<script src="library/bootstrap/js/jquery.dataTables.min.js"></script>
<script src="library/bootstrap/js/scripts.js"></script>
<script src="library/bootstrap/js/scripts-1.9.1.js"></script>
<script src="library/bootstrap/js/DT_bootstrap.js"></script>
<script src="vendors/datatables/src/model/model.defaults.js"></script>
<script src="vendors/datatables/unit_testing/tests_onhold/1_dom/aoColumns.bSearchable.js"></script>
<!-- page script -->
<script>
  $(function () {
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
    $('#table-search').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : false,
      'info'        : true,
      'autoWidth'   : true
    })
  })
</script>
<script src="../vendor/js/jquery-2.1.1.min.js"></script>
    <script src="../vendor/js/bootstrap.min.js"></script>
    <script src="../vendor/js/chart/moment.min.js"></script>
    <script src="../vendor/js/chart/chart.min.js"></script>
    <script src="../vendor/js/app.js"></script>

</body>
</html>
