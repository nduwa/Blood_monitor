          <?php
            $top_msg_status = 0;
            $top_sql_msg = "SELECT * FROM bloodrequest WHERE bl_status = '$top_msg_status' ORDER BY bl_rid DESC";
            $top_result_msg = $conn->query($top_sql_msg);
            echo $conn->error;
          ?>
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success"><?php echo $top_result_msg->num_rows; ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have <?php echo $top_result_msg->num_rows; ?> new messages</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <?php
                  $toper_sql_msg = "SELECT * FROM bloodrequest ORDER BY bl_rid DESC LIMIT 6";
                  $toper_result_msg = $conn->query($toper_sql_msg);
                  while ($toper_row_msg = $toper_result_msg->fetch_assoc()) {
                    if ($toper_row_msg['bl_status'] == 1){ $bck = "style='background: #d2d6de;'";}
                    else { $bck = ""; }

                    $t_disp = "";
                    if ($toper_row_msg['bl_date'] == date("Y/m/d")) {
                      $t = mktime($toper_row_msg['bl_time']);
                      $t_disp = date("h:i A", $t);
                    }
                    else { 
                      $t = strtotime($toper_row_msg['bl_date']);
                      $t_disp = date("l", $t);
                    }
                  ?>
                  <li <?php echo $bck; ?> ><!-- start message -->
                    <a href="php/action.php?readmail=<?php echo $toper_row_msg['bl_rid']; ?>">
                      <div class="pull-left">
<!--                         <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
 -->                  <i class="fa fa-envelope-o"></i>   
                      </div>
                      <h4>
                        <?php echo $toper_row_msg['bl_username']; ?>
                        <small><i class="fa fa-clock-o"></i> <?php echo $t_disp; ?></small>
                      </h4>
                      <p><?php 
                      echo $toper_row_msg['bl_code'].'&nbsp;&nbsp;'.$toper_row_msg['bl_type']; ?></p>
                    </a>
                  </li>
                  <!-- end message -->
                  <?php } ?>
                </ul>
              </li>
              <li class="footer"><a href="home.php?view=mailbox&pg=0">See All Messages</a></li>
            </ul>
          </li>

          <!-- Tasks: style can be found in dropdown.less -->