-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2018 at 01:08 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifeserveblood`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_teen`
--

CREATE TABLE `about_teen` (
  `short_msg` varchar(1000) NOT NULL,
  `welcome_msg` varchar(5000) NOT NULL,
  `teen_definition` text NOT NULL,
  `what_we_do` text NOT NULL,
  `our_vision` text NOT NULL,
  `our_mission` text NOT NULL,
  `msg_status` enum('0','1','2') NOT NULL DEFAULT '0',
  `welcome_status` enum('0','1','2') NOT NULL DEFAULT '0',
  `definition_status` enum('0','1','2') NOT NULL DEFAULT '0',
  `we_do_status` enum('0','1','2') NOT NULL DEFAULT '0',
  `vision_status` enum('0','1','2') NOT NULL DEFAULT '0',
  `mission_status` enum('0','1','2') NOT NULL DEFAULT '0',
  `partnership_status` enum('0','1','2') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `about_teen`
--

INSERT INTO `about_teen` (`short_msg`, `welcome_msg`, `teen_definition`, `what_we_do`, `our_vision`, `our_mission`, `msg_status`, `welcome_status`, `definition_status`, `we_do_status`, `vision_status`, `mission_status`, `partnership_status`) VALUES
('Rwandaâ€™s National Center for Blood Transfusion Attains International Standards', '<p></p><p></p>\r\n\r\n<p><i>Dear Visitors,</i></p><p>We welcome you all to this official website of <b>Teen Mothers Integrated (TMI)</b>. TMI recognizes that by working together we can create synergy and intensify the dynamics to improve the status of teen mothers and their children for their sustainable socio-economic development. TMI is therefore established and fully committed to providing its contribution to ongoing national efforts to have communities free of teen pregnancies through inspiring teen mothers to restore hope and be strong, smart and bold. Your views and ideas and any other support as stakeholders are of paramount importance to change the lives of teen mothers and their children.</p><h4><b></b>You are most welcome again.<b></b></h4>\r\n\r\n<br><p></p>', '', '<p>\r\n\r\n\r\n\r\nBlood transfusion implies giving of human blood to a person needing it. The person in need of the transfusion may have severe chronic anemia (lack of adequate blood) due to nutritional deficiency, causing damage to body parts like the heart, kidneys, limbs e.t.c.\r\n\r\n\r\n<br></p>', 'To become a Center of Excellence for the prosperity of the country, ensuring quality health service delivery, education and research.\r\n\r\n\r\n<br>', '<p>\r\n\r\n\r\n\r\nRwanda established the National Center for Blood Transfusion (NCBT) with the mission to provide safe, effective, and adequate blood and blood products to all patients in need. This is done by collecting blood exclusively from low risk VNRBD(Voluntary,Non-Remunerated Blood Donation) and tests each sample for TTIs(Travel Tech Israel) by using QMS(Quality Management Service). This paper showcases NCBT operations in ensuring safe blood and blood products.\r\n\r\n\r\n<br></p>', '', '0', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequest`
--

CREATE TABLE `bloodrequest` (
  `bl_rid` int(11) NOT NULL,
  `bl_username` varchar(50) NOT NULL,
  `bl_user_title` varchar(45) NOT NULL,
  `parent_user` varchar(45) NOT NULL,
  `bl_type` varchar(20) NOT NULL,
  `bl_quantity` int(11) NOT NULL,
  `served_quantity` int(11) DEFAULT NULL,
  `bl_comment` varchar(100) NOT NULL,
  `bl_status` enum('0','1') NOT NULL DEFAULT '0',
  `bl_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bloodrequest`
--

INSERT INTO `bloodrequest` (`bl_rid`, `bl_username`, `bl_user_title`, `parent_user`, `bl_type`, `bl_quantity`, `served_quantity`, `bl_comment`, `bl_status`, `bl_date`) VALUES
(1, 'Gloria', '2', '27', '9', 8, 7, ' Delivery for surgery ', '1', '2018-06-10'),
(2, 'MANISHIMWE alpha', '3', '27', '3', 10, 9, ' Injection for accident injury', '1', '2018-06-10'),
(3, 'MANISHIMWE alpha', '6', '27', '7', 15, 9, ' accident injury', '1', '2018-06-10'),
(4, 'Gloria', '2', '27', '9', 5, 7, ' yego', '1', '2018-06-11');

-- --------------------------------------------------------

--
-- Table structure for table `bloodstore`
--

CREATE TABLE `bloodstore` (
  `bl_id` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `user_title` varchar(45) NOT NULL,
  `bl_type_id` varchar(10) NOT NULL,
  `utility_id` int(11) NOT NULL,
  `bl_qntes` int(11) NOT NULL,
  `bl_time` time NOT NULL,
  `bl_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `blood_type`
--

CREATE TABLE `blood_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(45) NOT NULL,
  `type_code` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blood_type`
--

INSERT INTO `blood_type` (`type_id`, `type_name`, `type_code`) VALUES
(3, 'AB-', 'BL8780'),
(4, 'A-', 'BL250'),
(5, 'O-', 'BL6650'),
(6, 'B-', 'BL4938'),
(7, 'A+', 'BL3427'),
(8, 'B+', 'BL9578'),
(9, 'AB+', 'BL3369'),
(10, 'O+', 'BL164');

-- --------------------------------------------------------

--
-- Table structure for table `blood_utility`
--

CREATE TABLE `blood_utility` (
  `utility_id` int(11) NOT NULL,
  `utility_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blood_utility`
--

INSERT INTO `blood_utility` (`utility_id`, `utility_name`) VALUES
(1, 'usable'),
(2, 'wastage');

-- --------------------------------------------------------

--
-- Table structure for table `distributed_blood`
--

CREATE TABLE `distributed_blood` (
  `distributed_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `user_title` int(11) NOT NULL,
  `blood_id` varchar(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `distributed_blood`
--

INSERT INTO `distributed_blood` (`distributed_id`, `request_id`, `user_title`, `blood_id`, `quantity`, `date`) VALUES
(1, 7, 2, '9', 5, '2018-06-10'),
(2, 9, 6, '7', 9, '2018-06-10'),
(3, 9, 3, '3', 10, '2018-06-10');

-- --------------------------------------------------------

--
-- Table structure for table `donors`
--

CREATE TABLE `donors` (
  `don_id` int(11) NOT NULL,
  `card_id` varchar(45) NOT NULL,
  `don_name` varchar(100) NOT NULL,
  `don_lname` varchar(44) NOT NULL,
  `don_email` varchar(30) NOT NULL,
  `don_phone` varchar(12) NOT NULL,
  `don_address` varchar(20) NOT NULL,
  `don_blood_type` varchar(10) NOT NULL,
  `collector` varchar(45) NOT NULL,
  `don_time` time NOT NULL,
  `don_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `donors`
--

INSERT INTO `donors` (`don_id`, `card_id`, `don_name`, `don_lname`, `don_email`, `don_phone`, `don_address`, `don_blood_type`, `collector`, `don_time`, `don_date`) VALUES
(1, 'BD5483', 'Patrick', 'Jonah', 'oo@gnnn.net', '08956569856', 'kigali', '3', 'boss', '11:33:00', '2018-06-07');

-- --------------------------------------------------------

--
-- Table structure for table `places`
--

CREATE TABLE `places` (
  `place_id` int(11) NOT NULL,
  `place_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `places`
--

INSERT INTO `places` (`place_id`, `place_name`) VALUES
(1, 'NCBT-Admin'),
(2, 'NCBT-Worker'),
(3, 'RCBT-Admin'),
(4, 'RCBT-Worker'),
(5, 'Health-Admin'),
(6, 'Health-Worker');

-- --------------------------------------------------------

--
-- Table structure for table `served_blood`
--

CREATE TABLE `served_blood` (
  `served_id` int(11) NOT NULL,
  `patient_name` varchar(45) NOT NULL,
  `blood_type_id` varchar(11) NOT NULL,
  `blood_quantity` int(11) NOT NULL,
  `reason` varchar(45) NOT NULL,
  `served_by` int(11) NOT NULL,
  `serve_user` varchar(45) NOT NULL,
  `served_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `served_blood`
--

INSERT INTO `served_blood` (`served_id`, `patient_name`, `blood_type_id`, `blood_quantity`, `reason`, `served_by`, `serve_user`, `served_date`) VALUES
(1, 'NDAHIMANA Venutse', '9', 5, 'He had a liver surgery', 7, 'Gloria', '2018-06-10'),
(2, 'BAHIZI Robert', '7', 1, 'He had a liver surgery', 9, 'MANISHIMWE alpha', '2018-06-10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bloodstore_backup`
--

CREATE TABLE `tbl_bloodstore_backup` (
  `backup_id` int(11) NOT NULL,
  `backup_season` varchar(45) NOT NULL,
  `bachup_username` int(11) NOT NULL,
  `backup_user_title` int(11) NOT NULL,
  `backup_blood_type` int(11) NOT NULL,
  `backup_utilite` int(11) NOT NULL,
  `backup_quantity` int(11) NOT NULL,
  `backup_reason` varchar(45) NOT NULL,
  `backup_time` time NOT NULL,
  `backup_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cordinates`
--

CREATE TABLE `tbl_cordinates` (
  `cordinate_id` int(11) NOT NULL,
  `longitude` double NOT NULL,
  `latitude` double NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_cordinates`
--

INSERT INTO `tbl_cordinates` (`cordinate_id`, `longitude`, `latitude`, `post_id`) VALUES
(2, 30.060881, -1.955643, 1),
(3, 30.060881, -1.955643, 2),
(4, 29.637296, -1.506925, 3),
(5, 29.734939, -2.610341, 4),
(6, 29.346178, -2.067513, 5),
(7, 30.433384, -1.950587, 6),
(8, 30.060881, -1.955643, 7),
(9, 30.095214, -1.943636, 8),
(10, 29.747718, -2.607042, 9),
(11, 29.75073, -2.103509, 10),
(12, 30.111948, -1.930487, 11),
(13, 29.786716, -1.63834, 12);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_distributed_blood_backup`
--

CREATE TABLE `tbl_distributed_blood_backup` (
  `dis_backup_id` int(11) NOT NULL,
  `backup_requestor` int(11) NOT NULL,
  `back_distributor` int(11) NOT NULL,
  `backup_blood_id` int(11) NOT NULL,
  `backup_quantity` int(11) NOT NULL,
  `backup_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_distributed_blood_backup`
--

INSERT INTO `tbl_distributed_blood_backup` (`dis_backup_id`, `backup_requestor`, `back_distributor`, `backup_blood_id`, `backup_quantity`, `backup_date`) VALUES
(1, 7, 2, 9, 8, '2018-06-10'),
(2, 9, 6, 7, 10, '2018-06-10'),
(3, 9, 3, 3, 10, '2018-06-10'),
(4, 7, 2, 9, 2, '2018-06-11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_patient`
--

CREATE TABLE `tbl_patient` (
  `patient_id` int(11) NOT NULL,
  `patient_code` varchar(45) NOT NULL,
  `patient_name` varchar(45) NOT NULL,
  `patient_age` int(11) NOT NULL,
  `patient_district` varchar(45) NOT NULL,
  `patient_sector` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_regions`
--

CREATE TABLE `tbl_regions` (
  `region_id` int(11) NOT NULL,
  `region_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_regions`
--

INSERT INTO `tbl_regions` (`region_id`, `region_name`) VALUES
(1, 'Kigali City'),
(2, 'Northen Province'),
(3, 'Southen Province'),
(4, 'Weastern Province'),
(5, 'Eastern Province');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_summation`
--

CREATE TABLE `tbl_summation` (
  `sum_id` int(11) NOT NULL,
  `location` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `teen_posters`
--

CREATE TABLE `teen_posters` (
  `post_id` int(11) NOT NULL,
  `post_name` varchar(25) NOT NULL,
  `region_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teen_posters`
--

INSERT INTO `teen_posters` (`post_id`, `post_name`, `region_id`) VALUES
(1, 'NCBT-Rwanda', 1),
(2, 'RCBT-Kigali', 1),
(3, 'RCBT-Ruhengeli', 2),
(4, 'RCBT-Huye', 3),
(5, 'RCBT-Kibuye', 4),
(6, 'RCBT-Rwamagana', 5),
(7, 'Health-CHUK', 1),
(8, 'Health-King Faisal', 1),
(9, 'Health-Kabutare', 3),
(10, 'Health-Kabgayi', 3),
(11, 'Health-Kibagabaga', 1),
(12, 'Health-Nemba', 2);

-- --------------------------------------------------------

--
-- Table structure for table `teen_privileges`
--

CREATE TABLE `teen_privileges` (
  `post_id` int(11) NOT NULL,
  `give_privilege` enum('0','1') NOT NULL DEFAULT '0',
  `act_about` enum('0','1') NOT NULL DEFAULT '0',
  `act_contact` enum('0','1') NOT NULL DEFAULT '0',
  `act_event` enum('0','1') NOT NULL DEFAULT '0',
  `act_gallery` enum('0','1') NOT NULL DEFAULT '0',
  `act_instrument` enum('0','1') NOT NULL DEFAULT '0',
  `act_partner` enum('0','1') NOT NULL DEFAULT '0',
  `act_program` enum('0','1') NOT NULL DEFAULT '0',
  `act_publication` enum('0','1') NOT NULL DEFAULT '0',
  `act_slideshow` enum('0','1') NOT NULL DEFAULT '0',
  `act_posts` enum('0','1') NOT NULL DEFAULT '0',
  `act_testimony` enum('0','1') NOT NULL DEFAULT '0',
  `act_user` enum('0','1') NOT NULL DEFAULT '0',
  `add_contact` enum('0','1') NOT NULL DEFAULT '0',
  `add_event` enum('0','1') NOT NULL DEFAULT '0',
  `add_gallery` enum('0','1') NOT NULL DEFAULT '0',
  `add_instrument` enum('0','1') NOT NULL DEFAULT '0',
  `add_partner` enum('0','1') NOT NULL DEFAULT '0',
  `add_program` enum('0','1') NOT NULL DEFAULT '0',
  `add_publication` enum('0','1') NOT NULL DEFAULT '0',
  `add_slideshow` enum('0','1') NOT NULL DEFAULT '0',
  `add_posts` enum('0','1') NOT NULL DEFAULT '0',
  `add_testimony` enum('0','1') NOT NULL DEFAULT '0',
  `add_user` enum('0','1') NOT NULL DEFAULT '0',
  `add_about` enum('0','1') NOT NULL DEFAULT '0',
  `acc_mail` enum('0','1') NOT NULL DEFAULT '0',
  `acc_visitation` enum('0','1') NOT NULL DEFAULT '0',
  `acc_users` enum('0','1') NOT NULL DEFAULT '0',
  `acc_donor` enum('0','1') NOT NULL DEFAULT '0',
  `user_access` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teen_privileges`
--

INSERT INTO `teen_privileges` (`post_id`, `give_privilege`, `act_about`, `act_contact`, `act_event`, `act_gallery`, `act_instrument`, `act_partner`, `act_program`, `act_publication`, `act_slideshow`, `act_posts`, `act_testimony`, `act_user`, `add_contact`, `add_event`, `add_gallery`, `add_instrument`, `add_partner`, `add_program`, `add_publication`, `add_slideshow`, `add_posts`, `add_testimony`, `add_user`, `add_about`, `acc_mail`, `acc_visitation`, `acc_users`, `acc_donor`, `user_access`) VALUES
(1, '1', '1', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1'),
(2, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0', '1', '1', '1', '1', '1', '0'),
(3, '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0', '1', '0'),
(4, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '1', '0', '0'),
(5, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0'),
(6, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(7, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(8, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(9, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(10, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(11, '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `usertype` varchar(44) NOT NULL,
  `user_phone` varchar(15) NOT NULL,
  `user_email` varchar(60) NOT NULL,
  `user_password` varchar(80) NOT NULL,
  `profile` varchar(70) NOT NULL,
  `reg_date` date NOT NULL,
  `user_title` int(11) NOT NULL,
  `user_place` int(11) NOT NULL,
  `user_status` enum('0','1','2') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `usertype`, `user_phone`, `user_email`, `user_password`, `profile`, `reg_date`, `user_title`, `user_place`, `user_status`) VALUES
(27, 'Fidele', 'Blood Transfusion', '0788779903', 'fidel@gmail.com', '202cb962ac59075b964b07152d234b70', 'default_profile.png', '2018-05-07', 1, 1, '1'),
(28, 'files', 'Fidele', '12456987', 'file@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-05-08', 1, 2, '1'),
(30, 'Pacifique', '27', '12345688', 'nduwapaci12@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-05-09', 1, 1, '1'),
(33, 'Emile', '27', '078633', 'emi@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-05-09', 7, 5, '1'),
(34, 'boss', '27', '4555', 'boss@gmail.com', '250cf8b51c773f3f8dc8b4be867a9a02', 'default_profile.png', '2018-05-09', 2, 3, '1'),
(36, 'vital', '34', '089555', 'vital@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-05-10', 2, 4, '1'),
(37, 'Lea', '34', '07854561', 'lea@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-05-21', 2, 5, '1'),
(38, 'mukunzi', '34', '078955466', 'm@g.c', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-05-21', 8, 5, '1'),
(39, 'Pacifique', '34', '0782289359', 'nduwapaci12@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-02', 3, 3, '1'),
(40, 'vick', '33', '01578554545', 'v@v.v', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-02', 4, 3, '1'),
(41, 'paco', '27', '+250783686203', 'paci@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-08', 1, 2, '1'),
(42, 'Gloria', '27', '0782289378', 'gog3@yahoo.fr', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 7, 6, '1'),
(43, 'MANIRIHO Claude', '27', '0788884515', 'claude@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 3, 3, '1'),
(44, 'BUGINGOBWIMANA Theogene', '27', '0788883515', 'theogene@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 3, 4, '1'),
(45, 'MANISHIMWE alpha', '27', '0788882515', 'alpha@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 9, 5, '1'),
(46, 'MUYOMBO Thomas', '27', '0788885515', 'thomas@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 9, 6, '1'),
(47, 'MUGISHA theobal', '27', '0788886515', 'theobal@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 8, 5, '1'),
(48, 'NIZERERE Paul', '27', '0788887515', 'paul@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 8, 6, '1'),
(49, 'KIBUYE felicien', '27', '0788888515', 'felicien@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 5, 5, '1'),
(50, 'KIBUYE felicien', '27', '0788888515', 'felicien@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 5, 3, '1'),
(51, 'KIBUYE serge', '27', '0788889515', 'serge@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 5, 4, '1'),
(52, 'RWAMAGANA justin', '27', '0788825158', 'rwamaganaJ@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 6, 3, '1'),
(53, 'RWAMAGANA nathan', '27', '0788835158', 'nathan@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 6, 4, '1'),
(54, 'HUYE Vianney', '27', '0788845158', 'huyev@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 4, 3, '1'),
(55, 'HUYE jean', '27', '0788855158', 'huyeje@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 4, 4, '1'),
(56, 'KIGALI pacific', '27', '0788865158', 'paci@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 2, 3, '1'),
(57, 'KIGALI hugo', '27', '0788885158', 'kigalihu@gmail.com', '6b157916b43b09df5a22f658ccb92b64', 'default_profile.png', '2018-06-10', 2, 4, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_privilegie`
--

CREATE TABLE `user_privilegie` (
  `place_id` int(11) NOT NULL,
  `user_acess` int(11) NOT NULL,
  `add_user` int(11) NOT NULL,
  `act_user` int(11) NOT NULL,
  `act_level` int(11) NOT NULL,
  `act_model` int(11) NOT NULL,
  `act_type` int(11) NOT NULL,
  `user_view` int(11) NOT NULL,
  `act_location` int(11) NOT NULL,
  `view_location` int(11) NOT NULL,
  `user_right` int(11) NOT NULL,
  `act_region` int(11) NOT NULL,
  `acc_region` int(11) NOT NULL,
  `acc_nation` int(11) NOT NULL,
  `act_utility` int(11) NOT NULL,
  `acc_utility` int(11) NOT NULL,
  `acc_donor` int(11) NOT NULL,
  `acc_request` int(11) NOT NULL,
  `acc_bloodstore` int(11) NOT NULL,
  `acc_heathstore` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_privilegie`
--

INSERT INTO `user_privilegie` (`place_id`, `user_acess`, `add_user`, `act_user`, `act_level`, `act_model`, `act_type`, `user_view`, `act_location`, `view_location`, `user_right`, `act_region`, `acc_region`, `acc_nation`, `act_utility`, `acc_utility`, `acc_donor`, `acc_request`, `acc_bloodstore`, `acc_heathstore`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0),
(2, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0),
(1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0),
(2, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0),
(3, 0, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0),
(4, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0),
(5, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1),
(6, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodrequest`
--
ALTER TABLE `bloodrequest`
  ADD PRIMARY KEY (`bl_rid`);

--
-- Indexes for table `bloodstore`
--
ALTER TABLE `bloodstore`
  ADD PRIMARY KEY (`bl_id`);

--
-- Indexes for table `blood_type`
--
ALTER TABLE `blood_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `blood_utility`
--
ALTER TABLE `blood_utility`
  ADD PRIMARY KEY (`utility_id`);

--
-- Indexes for table `distributed_blood`
--
ALTER TABLE `distributed_blood`
  ADD PRIMARY KEY (`distributed_id`);

--
-- Indexes for table `donors`
--
ALTER TABLE `donors`
  ADD PRIMARY KEY (`don_id`);

--
-- Indexes for table `places`
--
ALTER TABLE `places`
  ADD PRIMARY KEY (`place_id`);

--
-- Indexes for table `served_blood`
--
ALTER TABLE `served_blood`
  ADD PRIMARY KEY (`served_id`),
  ADD KEY `serve_user` (`serve_user`),
  ADD KEY `served_by` (`served_by`),
  ADD KEY `served_by_2` (`served_by`);

--
-- Indexes for table `tbl_bloodstore_backup`
--
ALTER TABLE `tbl_bloodstore_backup`
  ADD PRIMARY KEY (`backup_id`);

--
-- Indexes for table `tbl_cordinates`
--
ALTER TABLE `tbl_cordinates`
  ADD PRIMARY KEY (`cordinate_id`);

--
-- Indexes for table `tbl_distributed_blood_backup`
--
ALTER TABLE `tbl_distributed_blood_backup`
  ADD PRIMARY KEY (`dis_backup_id`);

--
-- Indexes for table `tbl_patient`
--
ALTER TABLE `tbl_patient`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `patient_code` (`patient_code`);

--
-- Indexes for table `tbl_regions`
--
ALTER TABLE `tbl_regions`
  ADD PRIMARY KEY (`region_id`);

--
-- Indexes for table `tbl_summation`
--
ALTER TABLE `tbl_summation`
  ADD PRIMARY KEY (`sum_id`);

--
-- Indexes for table `teen_posters`
--
ALTER TABLE `teen_posters`
  ADD PRIMARY KEY (`post_id`),
  ADD UNIQUE KEY `post_name` (`post_name`);

--
-- Indexes for table `teen_privileges`
--
ALTER TABLE `teen_privileges`
  ADD UNIQUE KEY `post_id` (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bloodrequest`
--
ALTER TABLE `bloodrequest`
  MODIFY `bl_rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bloodstore`
--
ALTER TABLE `bloodstore`
  MODIFY `bl_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blood_type`
--
ALTER TABLE `blood_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `blood_utility`
--
ALTER TABLE `blood_utility`
  MODIFY `utility_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `distributed_blood`
--
ALTER TABLE `distributed_blood`
  MODIFY `distributed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donors`
--
ALTER TABLE `donors`
  MODIFY `don_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `places`
--
ALTER TABLE `places`
  MODIFY `place_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `served_blood`
--
ALTER TABLE `served_blood`
  MODIFY `served_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_bloodstore_backup`
--
ALTER TABLE `tbl_bloodstore_backup`
  MODIFY `backup_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cordinates`
--
ALTER TABLE `tbl_cordinates`
  MODIFY `cordinate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_distributed_blood_backup`
--
ALTER TABLE `tbl_distributed_blood_backup`
  MODIFY `dis_backup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_patient`
--
ALTER TABLE `tbl_patient`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_regions`
--
ALTER TABLE `tbl_regions`
  MODIFY `region_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_summation`
--
ALTER TABLE `tbl_summation`
  MODIFY `sum_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teen_posters`
--
ALTER TABLE `teen_posters`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
