<?php 
session_start();
if(isset($_SESSION["teenUser_id"]) && !empty($_SESSION["teenUser_id"])) 
  { header('location: home.php?view=Model'); }?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Blood Monitor Login</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="library/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="library/css/sb-admin.css" rel="stylesheet">
</head>
<body class="bg-default">
  <div class="container">
    <div class="card card-login mx-auto mt-5" 
    style="background-color: skyblue; border: solid .1em red;box-shadow: 0px 0px 10px rgba(0, 0, 0, 3);
    border-radius: 1.5em; color: #009;font-size: 1.3em;">
      <div class="card-header"> <p align="center">Login</p></div>
      <div class="card-body">
       <div class="text-center">
          <img src="dist/img/logo.png" width="100%"></div><br>
        <form action="php/action.php" method="post">
          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input class="form-control" name="email" type="email" placeholder="Enter email">
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input class="form-control" id="exampleInputPassword1" name="passcode" type="password" placeholder="Password">
          </div>
          <button class="btn btn-info btn-block" name="login">Login</button>
          <a href="forget_password.php">Forget password</a>

        </form><br>
        
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>
