    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">New Gallery Image</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <button type="button" class="btn btn-default btn-sm active"><i class="fa fa-square text-green"></i>
                  </button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-square text-red"></i></button>
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">
                   

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputLastName">Image</label>
                          <input type="file" name="images[]" accept="image/*" multiple="multiple">
                        </div>
                        <div class="col-md-4">
                          <label for="exampleInputLastName"></label>
                          <button  name = "add_gallery" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>


                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>