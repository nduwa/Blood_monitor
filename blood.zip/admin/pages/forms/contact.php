   <?php
      $sql = "SELECT * FROM contact";
      $result = $conn->query($sql);
      $row = $result->fetch_assoc();
      if ($result->num_rows > 0) { $name = "update_contact"; }
      else { $name = "insert_contact"; }
   ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Add/Update Contacts</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <button type="button" class="btn btn-default btn-sm active"><i class="fa fa-square text-green"></i>
                  </button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-square text-red"></i></button>
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form method="post" action="php/action.php" >
                    <!-- phone mask -->
                    <div class="form-group">
                      <label>Phone Number:</label>

                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-phone"></i>
                        </div>
                        <input type="text" class="form-control" value="<?php echo $row['contact_phone']; ?>" name="phone" />
                      </div>
                      <!-- /.input group -->
                    </div>
                    <!-- /.form group -->

                    <!-- Email mask -->
                    <div class="form-group">
                      <label>Email:</label>

                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-envelope"></i>
                        </div>
                        <input type="email" class="form-control" value="<?php echo $row['contact_email']; ?>" name="email" />
                      </div>
                      <!-- /.input group -->
                    </div>
                    <!-- /.form group -->

                    <!-- phone mask -->
                    <div class="form-group">
                      <label>Address:</label>

                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-map-marker"></i>
                        </div>
                        <input type="text" class="form-control" value="<?php echo $row['contact_address']; ?>" name="address" />
                      </div>
                      <!-- /.input group -->
                    </div>
                    <!-- /.form group -->

                    <!-- phone mask -->
                    <div class="form-group">
                      <label>Facebook Page:</label>

                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-facebook text-blue"></i>
                        </div>
                        <input type="url" class="form-control" value="<?php echo $row['contact_fb']; ?>" name="facebook" />
                      </div>
                      <!-- /.input group -->
                    </div>
                    <!-- /.form group -->

                    <!-- phone mask -->
                    <div class="form-group">
                      <label>Twitter Page:</label>

                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-twitter text-aqua"></i>
                        </div>
                        <input type="url" class="form-control" value="<?php echo $row['contact_tw']; ?>" name="twitter" />
                      </div>
                      <!-- /.input group -->
                    </div>
                    <!-- /.form group -->


                    <!-- phone mask -->
                    <div class="form-group">
                      <label>Gmail+ Page:</label>

                      <div class="input-group">
                        <div class="input-group-addon">
                          <i class="fa fa-google-plus text-red"></i>
                        </div>
                        <input type="url" class="form-control" value="<?php echo $row['contact_gplus']; ?>" name="gplus" />
                      </div>
                      <!-- /.input group -->
                    </div>
                    <!-- /.form group -->
                     <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-3">
                          <label for="exampleInputLastName"></label>
                          <button type="submit" name = "<?php echo $name; ?>" class="btn btn-success btn-block">
                            <i class="fa fa-save"></i> Save</button>
                        </div>
                        <div class="col-md-4">
                          
                        </div>
                        <div class="col-md-5">
                        </div>
                      </div>
                    </div>


                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>