<?php
$pid = "";
$cont = "";
$title = "";
if(isset($_REQUEST['pedit'])) {
  $pid = $_REQUEST['pid'];
  $sql = "SELECT * FROM donors WHERE don_id = '$pid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  $action = "update_donor";
}
?>
    <!-- Main content -->
     <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Blood Donation</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <button type="button" class="btn btn-default btn-sm active"><i class="fa fa-square text-green"></i>
                  </button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-square text-red"></i></button>
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label>Collection Name</label>
                          <input class="form-control" name="colle_name" type="text" placeholder="Enter the Name of Collection..." required >
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Card_ID</label>
                          <input class="form-control" name="card" type="text" placeholder="Enter the blood card number..." required value="<?php echo $row['card_id']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">First Name</label>
                          <input class="form-control" name="fname" type="text" placeholder="Enter First Name..." required value="<?php echo $row['don_name']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Last Name</label>
                          <input class="form-control" name="lname" type="text" placeholder="Enter Last Name..." required value="<?php echo $row['don_lname']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Email</label>
                          <input class="form-control" name="don_email" type="email" placeholder="Enter the Email Address..." value="<?php echo $row['don_email']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Telephone</label>
                          <input class="form-control" name="don_phone" type="phone" placeholder="Enter the Telephone number..." value="<?php echo $row['don_phone']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Address</label>
                          <input class="form-control" name="don_address" type="text" placeholder="Enter the Address..." value="<?php echo $row['don_address']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Blood Type</label>
                          <input type="text" class="form-control" name="blood_type" placeholder="Enter the Email Address..." value="<?php echo $row['don_blood_type']; ?>">                            
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Collection Site</label>
                          <input class="form-control" name="site" type="text" placeholder="Enter the Collection site...">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Donation</label>
                          <select class="form-control" name="donate" placeholder="Enter the Email Address...">
                            <option>--select--</option>
                            <option>Yes</option>
                            <option>No</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Collector</label>
                          <input class="form-control" name="collector" type="text" placeholder="Enter First Name..." required >
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <br />
                          <button  name = "<?php echo $action; ?>" value="<?php echo $pid; ?>" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>