<!-- Main content -->
<section class="content">
  <!-- Small boxes (Stat box) -->
  
  <!-- /.row -->
  <!-- Main row -->
  <div class="row">
    <section class="col-xs-10 ">
      <form action="php/action.php" method="post"> 
      <div class="box box-success">
        <div class="box-header">
          <i class="fa fa-users"></i>
          <h3 class="box-title">Add New Users</h3>
          <?php if(isset($_REQUEST['pass'])) { ?>
          <button type="button" class="btn btn-primary">Provided Password: 
            <span class="badge" style="font-size: 18px;"><?php echo $_REQUEST['pass']; ?></span>
          </button>
          <?php } ?>
      </div>
    </div>
          <div class="box-tools pull-right" data-toggle="tooltip" >
            <div class="btn-group" data-toggle="btn-toggle">
              <a href="home.php?view=user"><button type="button" class="btn btn-default btn-sm active" style="margin-top: -105px;"><i class=" text-green">view users</i>
              </button></a>
              
            </div>
          </div> 

       <div class="col-lg-12 col-md-12">
        <div class="card" style="background-color: #f9f9f9;">
            
            <div class="content">
                <form>
                    <div class="row">
                        <div class="col-md-0">
                            <div class="form-group">
                                 <input  class="form-control" name="username" id="name" type="hidden" value="<?php echo $row_user['user_id']; ?>">
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="exampleInputName">Name</label>
                                <input  class="form-control" name="name" id="name" type="text" aria-describedby="nameHelp" placeholder="Enter Your names ......    " required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="exampleInputName">Telephone</label>
                                <input  class="form-control" name="phone" id="phone" type="text" aria-describedby="nameHelp" placeholder="Enter your phone number......    " required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputLastName">Email Account</label>
                                <input  class="form-control" name="email" id="email" type="email" nameHelp" placeholder="Enter your email account...." required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text" class="form-control border-input" placeholder="Home Address" value="Please choose one according to where You work!!!!" disabled>
                            </div>
                        </div>
                        </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php 
                                if ($row_user['post_id'] == 1) {
                                  
                                
                                $sql = "SELECT * FROM teen_posters";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">Location</label>
                                <select class="form-control" id="user_title" name="user_title" aria-describedby="nameHelp" >
                                  <option disabled="disabled" selected="selected">select working location</option>
                                  <?php while($row = $result->fetch_assoc()){ ?>

                                  <option value="<?php echo $row['post_id']; ?>"><?php echo $row['post_name']; ?></option>
                                <?php }} ?>
                                </select> 
                                 <?php 
                                if (($row_user['post_id'] == 2) || ($row_user['post_id'] == 3) || ($row_user['post_id'] == 4) || ($row_user['post_id'] == 5) || ($row_user['post_id'] == 6)) {

                                $sql = "SELECT * FROM teen_posters WHERE post_name NOT LIKE 'NCBT%'";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">Location</label>
                                <select class="form-control" id="user_title" name="user_title" aria-describedby="nameHelp" >
                                  <option disabled="disabled" selected="selected">select working location</option>
                                  <?php while($row = $result->fetch_assoc()){ ?>

                                  <option value="<?php echo $row['post_id']; ?>"><?php echo $row['post_name']; ?></option>
                                <?php }}
                                if ($row_user['post_id'] > 6)  {

                                $sql = "SELECT * FROM teen_posters WHERE post_name  LIKE 'Health%' AND post_id ='".$row_user['post_id']."'";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">Location</label>
                                <select class="form-control" id="user_title" name="user_title" aria-describedby="nameHelp" >
                                  <option disabled="disabled" selected="selected">select working location</option>
                                  <?php while($row = $result->fetch_assoc()){ ?>

                                  <option value="<?php echo $row['post_id']; ?>"><?php echo $row['post_name']; ?></option>
                                <?php }} ?>
                                </select>

                            </div>
                        </div>
                       
                        <div class="col-md-6">
                            <div class="form-group">
                                <?php
                                if ($row_user['post_id'] == 1) {
                                 $sql = "SELECT * FROM places";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">Post</label>
                                <select class="form-control" id="place_title" name="place_title" aria-describedby="nameHelp" >
                                    <option disabled="disabled" selected="selected">Select working post</option>
                                    <?php while($row = $result->fetch_assoc()){ ?>
                                    <option value="<?php echo $row['place_id']; ?>"><?php echo $row['place_name']; ?></option>
                                <?php }} ?>
                                </select> 
                                <?php
                                if (($row_user['post_id'] == 2) || ($row_user['post_id'] == 3) || ($row_user['post_id'] == 4) || ($row_user['post_id'] == 5) || ($row_user['post_id'] == 6)) {
                                 $sql = "SELECT * FROM places WHERE place_name NOT LIKE 'NCBT%'";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">Post</label>
                                <select class="form-control" id="place_title" name="place_title" aria-describedby="nameHelp" >
                                    <option disabled="disabled" selected="selected">Select working post</option>
                                    <?php while($row = $result->fetch_assoc()){ ?>
                                    <option value="<?php echo $row['place_id']; ?>"><?php echo $row['place_name']; ?></option>
                                <?php }} ?>
                                </select> 
                                <?php
                                if ($row_user['post_id'] > 6)  {
                                 $sql = "SELECT * FROM places WHERE place_name  LIKE 'Health%'";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">Post</label>
                                <select class="form-control" id="place_title" name="place_title" aria-describedby="nameHelp" >
                                    <option disabled="disabled" selected="selected">Select working post</option>
                                    <?php while($row = $result->fetch_assoc()){ ?>
                                    <option value="<?php echo $row['place_id']; ?>"><?php echo $row['place_name']; ?></option>
                                <?php }} ?>
                                </select> 
                            </div>
                        </div>
                    </div>




                  
                    <div class="text-center">
                        <button type="submit" name= "add_user" class="btn btn-success btn-fill btn-wd">register</button>
                    </div>
                    <div class="clearfix"></div>
                </form>
            </div>
        </div>
    </div>         
  </div>
 </form>
</section>
</div>
</section>