<?php
$code = "";
$type = "";
$action = "serve_blood";
if(isset($_REQUEST['bloodReduction'])) {
  $tid = $_REQUEST['bloodReduction'];
  $sql = "SELECT * FROM distributed_blood WHERE distributed_id = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Form of Blood Reduction</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="home.php?view=health"><button type="button" class="btn btn-default btn-sm active"><i class=" text-green"> view store</i>
                  </button></a>
                  
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">

                    <div class="form-group">
                      <div class="col-md-8">
                        <input  class="form-control" name="user_title" id="user_title" type="hidden" value="<?php echo $row_user['user_title']; ?>">
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName"></label>
                          <input class="form-control" name="id" id="id" type="hidden" value="<?php echo $tid; ?>" invisible>
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName"></label>
                          <input class="form-control" name="blood_type" id="blood_type" type="hidden" value="<?php echo $row['blood_id']; ?>" invisible>
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">TO</label>
                          <input type="text" class="form-control" name="patient" placeholder="Who is assigned this sachet..." required> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Blood Quantity</label>
                          <input type="number" class="form-control" min="1" name="Quantity" placeholder="Enter the Blood Quantity..." required> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Comment</label>
                          <input class="form-control" name="Comment" placeholder="Why and who takethis sachet..." required> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputLastName"></label>
                          <input class="form-control" type="hidden" name="username" value="<?php echo $row_user['user_name']; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <br />
                          <button  name = "<?php echo $action; ?>" value = "<?php echo $tid; ?>" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>