   <?php
      $sql = "SELECT * FROM about_teen";
      $result = $conn->query($sql);
      $row = $result->fetch_assoc();
      if ($result->num_rows > 0) { $name = "update_info"; }
      else { $name = "insert_info"; }
   ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Add/Update Models</h3>

              <div class="box-tools pull-right" data-toggle="tooltip">
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="home.php?view=Model"><button type="button" class="btn btn-default btn-sm active"><i class=" text-green">View Model</i>
                  </button></a>
                  
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form method="post" action="php/action.php" >
                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-10">
                          <label for="exampleInputName">Blood Status Message</label>
                          <input type="text" class="form-control" name="Inspire_model" aria-describedby="nameHelp" placeholder="Enter the Status Message" value="<?php echo $row['short_msg']; ?>" />
                        </div>
                      </div>
                    </div>
                    
                     <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-10">
                          <label for="exampleInputName">What We do</label>
                          <textarea class="form-control textarea" name="work" id="work" type="text" aria-describedby="nameHelp" placeholder="Enter the Our work">
                            <?php echo $row['what_we_do']; ?>
                          </textarea>
                          
                        </div>
                      </div>
                    </div>

                     <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-10">
                          <label for="exampleInputName">Our Mission</label>
                          <textarea class="form-control textarea" name="mission" id="mission" type="text" aria-describedby="nameHelp" placeholder="Enter the Mission">
                            <?php echo $row['our_mission']; ?>
                          </textarea>
                          
                        </div>
                      </div>
                    </div>

                     <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-10">
                          <label for="exampleInputName">Our Vision</label>
                          <textarea class="form-control textarea" name="vision" id="vision" type="text" aria-describedby="nameHelp" placeholder="Enter the Vision..." >
                            <?php echo $row['our_vision']; ?>
                          </textarea>
                        </div>
                      </div>
                    </div>

                    <br><br>
                     <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-3">
                          <label for="exampleInputLastName"></label>
                          <button type="submit" name = "<?php echo $name; ?>" class="btn btn-success btn-block">
                            <i class="fa fa-save"></i> Save</button>
                        </div>
                        <div class="col-md-4">
                          
                        </div>
                        <div class="col-md-5">
                        </div>
                      </div>
                    </div>


                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>