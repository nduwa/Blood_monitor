<?php
$code = "";
$type = "";
$action = "send_request";
if(isset($_REQUEST['bloodRequest'])) {
  $tid = $_REQUEST['bloodRequest'];
  $sql = "SELECT * FROM distributed_blood WHERE distributed_id = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  $type = $row['blood_id'];
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Blood Request format</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="home.php?view=pub"><button type="button" class="btn btn-default btn-sm active"><i class=" text-green"> view store</i>
                  </button></a>
                  
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">

                    <div class="form-group">
                      <div class="col-md-8">
                        <input  class="form-control" name="username" id="name" type="hidden" value="<?php echo $row_user['user_name']; ?>">
                        <input  class="form-control" name="serve" id="serve" type="hidden" value="<?php echo $row_user['user_title']; ?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-md-8">
                                <?php $sql = "SELECT * FROM teen_posters WHERE post_name like 'RCBT%'";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">YOUR REGIONAL BLOOD CENTER</label>
                                <select class="form-control" id="user_title" name="user_title" aria-describedby="nameHelp" >
                                  <option disabled="disabled" selected="selected">REGIONAL STATION</option>
                                  <?php while($row = $result->fetch_assoc()){ ?>
                                  <option value="<?php echo $row['post_id']; ?>"><?php echo $row['post_name']; ?></option>
                                <?php } ?>
                                </select>
                                </div> 
                            </div>
                    <div class="form-group">
                      <div class="col-md-8">
                                <?php $sql = "SELECT * FROM blood_type";
                                $result = $conn->query($sql); ?>
                                <label for="exampleInputName">YOUR REGIONAL BLOOD STORE</label>
                                <select class="form-control" id="bl_type" name="bl_type" aria-describedby="nameHelp" >
                                  <option disabled="disabled" selected="selected">BLOOD TYPE</option>
                                  <?php while($row = $result->fetch_assoc()){ ?>
                                  <option value="<?php echo $row['type_id']; ?>"><?php echo $row['type_name']; ?></option>
                                <?php } ?>
                                </select> 
                                </div> 
                            </div>        
                    <div class="form-group">
                      <div class="col-md-8">
                        <input  class="form-control" name="usertype" id="name" type="hidden" value="<?php echo $row_user['usertype']; ?>">
                      </div>
                    </div>

                    

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Blood Quantity</label>
                          <input type="number" class="form-control" name="Quantity" placeholder="Enter the Blood Quantity..."> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Request Blood Comment</label>
                          <textarea class="form-control" name="Comment" placeholder="Enter the Blood Quantity..."> </textarea> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <br />
                          <button  name = "<?php echo $action; ?>" value = "<?php echo $tid; ?>" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>