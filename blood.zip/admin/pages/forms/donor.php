    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">New Blood Donor</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <button type="button" class="btn btn-default btn-sm active"><i class="fa fa-square text-green"></i>
                  </button>
                  <button type="button" class="btn btn-default btn-sm"><i class="fa fa-square text-red"></i></button>
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">


                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">First Name</label>
                          <input class="form-control" name="fname" type="text" placeholder="Enter First Name..." required>
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Last Name</label>
                          <input class="form-control" name="lname" type="text" placeholder="Enter Last Name..." required>
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Email</label>
                          <input class="form-control" name="don_email" type="email" placeholder="Enter the Email Address...">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Telephone</label>
                          <input class="form-control" name="don_phone" type="phone" placeholder="Enter the Telephone number...">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Address</label>
                          <input class="form-control" name="don_address" type="text" placeholder="Enter the Address...">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="col-md-8">
                        <?php $sql = "SELECT * FROM blood_type";
                        $result = $conn->query($sql); ?>
                        <label for="exampleInputName">YOUR REGIONAL BLOOD STORE</label>
                        <select class="form-control" id="blood_type" name="blood_type" aria-describedby="nameHelp" >
                          <option disabled="disabled" selected="selected">select blood type</option>
                          <?php while($row = $result->fetch_assoc()){ ?>
                          <option value="<?php echo $row['type_id']; ?>"><?php echo $row['type_name']; ?></option>
                        <?php } ?>
                        </select> 
                        </div> 
                    </div> 

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <input class="form-control" name="collector" type="hidden" value="<?php echo $row_user['user_name'] ?>" placeholder="Enter the name of Collector...">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <br />
                          <button  name = "add_donor" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>