<?php
if(isset($_REQUEST['Details'])) {
  $tid = $_REQUEST['Details'];
  $sql = "SELECT * FROM bloodstore JOIN teen_posters ON bloodstore.username = teen_posters.post_id WHERE username = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-9">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Blood Quantity of <?php echo $row['post_name']; ?></h3>
              <h3></h3>
              

              
            </div>

            <?php
            $sql = "SELECT * FROM bloodstore INNER JOIN blood_type ON bloodstore.bl_type_id = blood_type.type_id WHERE username = '$tid'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>

            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>

                  <th>Blood ID</th>
                  <th>Blood Type</th>
                  <th>Quantity</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  if ($row['utility_id'] == 1) {
                ?>
                <tr>
                    <td>
                    <?php echo $row['type_code']; ?></td>
                    <td>
                    <?php echo $row['type_name']; ?></td>
                    <td><b style="color: green;">
                    <?php echo $row['bl_qntes']; ?> Bath</b></td>
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php }} ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Blood Quantity Available!";
            } ?>
          </div>
          <!-- /.box -->

        </section>

      </div>
    </section>
  </div>