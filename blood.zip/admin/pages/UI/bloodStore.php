      <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_post";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $labels = " Type:";
      $label1 = " Season:";
      $label2 = " Reason:";
      $label = " Quantity:";
      $labe = " Utility:";
      $act = "newpub";
      $name = "";
      $id = ""; 
    }
    ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        
        <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">We use this form to store the quantity of blood after prepation</h3>
              <h3></h3>
              <div class="pull-right">
        
                <form action="php/action.php" method="post">
                  <input  class="form-control" name="userid" id="name" type="hidden" value="<?php echo $row_user['user_id']; ?>">
                  <input  class="form-control" name="username" id="username" type="hidden" value="<?php echo $row_user['user_title']; ?>">
                  <label><?php echo $label1; ?></label>
                  <input type="text" class="form-control" name="season" value="<?php echo $name; ?>" placeholder="collection season..." required>
                  <label><?php echo $labels; ?></label>
                  <?php $sql = "SELECT * FROM blood_type";
                            $result = $conn->query($sql); ?>
                        <select  id="Bloodtype" class="form-control" name="Bloodtype" aria-describedby="nameHelp" >
                          <option disabled="disabled" selected="selected">Select</option>
                          <?php while($row = $result->fetch_assoc()){ ?>
                          <option value="<?php echo $row['type_id']; ?>"><?php echo $row['type_name']; ?></option>
                          <?php } ?>
                        </select> 

                  
                  <label><?php echo $labe; ?></label>
                  <?php $sql = "SELECT * FROM blood_utility";
                            $result = $conn->query($sql); ?>
                        <select  id="Bloodtype" class="form-control" name="utile" aria-describedby="nameHelp" >
                          <option disabled="disabled" selected="selected">Select</option>
                          <?php while($row = $result->fetch_assoc()){ ?>
                          <option value="<?php echo $row['utility_id']; ?>"><?php echo $row['utility_name']; ?></option>
                          <?php } ?>
                        </select> 
                        <label><?php echo $label; ?></label>
                  <input type="number" class="form-control" name="post" value="<?php echo $name; ?>" placeholder="blood Quantity..." min="0" required>
                  <label><?php echo $label2; ?></label>
                  <textarea type="text"class="form-control" name="reason" cols="50" value="<?php echo $name; ?>" placeholder="reason..." required></textarea><hr>
                  <button type="submit" class="btn btn-info" name="<?php echo $act; ?>" value="<?php echo $id; ?>">
                    save</button>
                </form>
              </div>
            </div>
            
          </div>
          <!-- /.box -->

        </section>

        <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Store of Usable Blood</h3>
              <h3></h3>
             
            </div>
            <?php
            $sql = "SELECT * FROM bloodstore INNER JOIN blood_type ON bloodstore.bl_type_id = blood_type.type_id WHERE username = '" . $row_user['user_title']. "'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  <!-- <th>#</th> -->
                  <th>Blood ID</th>
                  <th>Blood Type</th>
                  <th>Quantity</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  if ($row['utility_id'] == 1) {
                ?>
                <tr>
                  <!-- <td><a href="php/action.php?pudel=<?php //echo $row['bl_id']; ?>" class="btn-sm bg-red">
                    <i class="fa fa-trash"></i></a></td>-->
                    <td> 
                    <?php echo $row['type_code']; ?></td>
                    <td>
                    <?php echo $row['type_name']; ?></td>
                    <td><b style="color: green;">
                    <?php echo $row['bl_qntes']; ?> Bath</b></td>

                </tr>
                <tr><td colspan="5"></td></tr>
                <?php }} ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Blood Quantity!";
            } ?>
          </div>
          <!-- /.box -->

        </section>

      </div>
    </section>
  </div>