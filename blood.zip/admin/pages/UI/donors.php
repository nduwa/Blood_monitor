    <!-- Main content -->
    <section class="content">
     
      <!-- Main row -->
       <div class="row">
        <div class="col-xs-10">
          <div class="box container">
            <div class="box-header">
              <h3 class="box-title">List of system Blood Donor</h3>
            <?php
            ?>
            <div style="margin-left: 90%;margin-top: -1em;">
              <a href="home.php?ADD=donor" class="btn-sm bg-blue">
              <i class="fa fa-edit"></i> New</a>
            </div>
            </div>
           
            <!-- /.box-header -->
    <?php
    $sql = "SELECT * FROM donors INNER JOIN blood_type ON donors.don_blood_type = blood_type.type_id";
    $result = $conn->query($sql);
    ?>
            <div class="box-body table-responsive no-padding">
              <table cellpadding="0" style="width: 95%; background: #fff;" cellspacing="0" border="0" class="table table-striped table-bordered" id="">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>CARD ID</th>
                        <th>NAMES</th>
                        <th>EMAIL</th>
                        <th>PHONE</th>
                        <th>LOCATION</th>
                        <th>BLOOD TYPE</th>
                      </tr>
                    </thead>
                    <?php
                    if ($result->num_rows > 0) { 
                      while($row = $result->fetch_assoc()) {?>
                    <tbody>
                      <tr class="odd gradeX">
                        <td><a href="home.php?ADD=Dona_up&pid=<?php echo $row['don_id']; ?>&pedit"><button type="button" class="btn btn-default btn-sm"><i class="fa fa-edit"></i></button></a></td>
                        <td><?php echo $row['card_id'];?></td>
                        <td><?php echo $row['don_name'].'&nbsp;'.$row['don_lname']; ?></td>
                        <td><?php echo $row['don_email'];?></td>
                        <td class="center"> <?php echo $row['don_phone'];?></td>
                        <td class="center"> <?php echo $row['don_address'];?></td>
                        <td class="center"> <?php echo $row['type_name'];?></td>
                      </tr>
                      <?php } } ?>
                    </tbody>
                  </table>
              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
        </div>
      </div>
    </section>