<?php
if(isset($_REQUEST['ncbt_view_rcbt_store_Details'])) {
  $tid = $_REQUEST['ncbt_view_rcbt_store_Details'];
  $sql = "SELECT * FROM teen_posters  WHERE post_id = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->

    <?php
    $sql_type = "SELECT * FROM  blood_type";
    $result_type = $conn->query($sql_type);
    $data_type = $result_type->num_rows;
    ?>
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
                   <!-- block -->
                <div class="block">
                    <div class="navbar navbar-inner block-header">
                        <div class="muted pull-left"><h4>This view shows the quantity of <b style="color: green;">Usable Blood</b> in the system</h4><br>
                          <span class="badge badge-info pull-right"style="font-size: 16px;"><?php echo $row['post_name']; ?></span><br>
                        <h5>Click on <b style="color: green;"> Details</b> to know how the blood are entered in the system</h5></div>
                        <div class="pull-right"><span class="badge badge-info"><?php echo $data_type; ?></span>

                        </div>
                    </div>
                    <div class="block-content collapse in">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Blood Type</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $n=1;
                                while ($row_type = $result_type->fetch_assoc()) {
                                  $id = $row_type['type_id'];
                                $sqls = "SELECT * FROM bloodstore WHERE bl_type_id = '$id' AND username = '$tid'";
                                $results = $conn->query($sqls);
                                $sum = 0;
                                while ($rows = $results->fetch_assoc()) {
                                  $out = $rows['bl_qntes'];
                                  $sum+=$out;
                                }
                               $name = $row_type['type_name'];
                               $num = $n++;
                               ?>
                                
                                <tr>
                                    <td><?php echo $num;?></td>
                                    <td><?php echo $name; ?></td>
                                    <td><b style="color: green;">
                                      <?php echo $sum; ?> Bath</b></td>
                                    <!-- <td><a href="home.php?view=rcbt_blood_report&rcbt_blood_entered_Details=<?php //echo $id;?>">Details...</a>
                                    </td> -->
                                </tr>
                              
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
                            <!-- /block -->
          </div>
          <!-- /.box -->


        </section>
            <?php
    $sql = "SELECT * FROM  blood_type";
    $result = $conn->query($sql);
    $data = $result->num_rows;
    ?>

        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
                   <!-- block -->
                <div class="block">
                    <div class="navbar navbar-inner block-header">
                        <div class="muted pull-left"><h4>This view shows the quantity of <b style="color: red;">Wastage Blood</b> in the system</h4><br>
                        <h5>Click on <b style="color: red;"> Details</b> to know how the wastage blood are entered in the system</h5></div>
                        <div class="pull-right"><span class="badge badge-info"><?php echo $data; ?></span>

                        </div>
                    </div>
                    <div class="block-content collapse in">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Blood Type</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $n=1;
                                while ($row = $result->fetch_assoc()) {
                                  $id = $row['type_id'];
                                $sqls = "SELECT * FROM tbl_bloodstore_backup WHERE backup_utilite = 2 AND backup_blood_type = '$id' AND bachup_username = '$tid'";
                                $results = $conn->query($sqls);
                                $sum = 0;
                                echo $conn->error;
                                while ($rows = $results->fetch_assoc()) {
                                  $out = $rows['backup_quantity'];
                                  $sum+=$out;
                                }
                               $name = $row['type_name'];
                               $num = $n++;
                               ?>
                                
                                <tr>
                                    <td><?php echo $num;?></td>
                                    <td><?php echo $name; ?></td>
                                    <td ><b style="color: red;"><?php echo $sum; ?> Bath</b></td>
                                    <td><a href="home.php?view=rcbt_blood_report&rcbt_blood_entered_Details=<?php echo $id;?>">Details...</a>
                                    </td>
                                </tr>
                              
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
                            <!-- /block -->
          </div>
          <!-- /.box -->


        </section>  

        

      </div>
    </section>
  </div>