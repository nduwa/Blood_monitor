        <section class="col-xs-4">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Addition Autorisation</h3>
            </div>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                


               

                <?php // ####### Action On Teen Testimony
                if ($row['act_level'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Set user level</td>
                  <td>
                    <a href="php/action.php?Levels=act_level&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### Action On Teen Testimony
                if ($row['user_view'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access to the user </td>
                  <td>
                    <a href="php/action.php?userView=user_view&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>
                 <?php // ####### Action On Teen Testimony
                if ($row['user_right'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access the user right </td>
                  <td>
                    <a href="php/action.php?useright=user_right&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>


                <?php // ####### Action On Teen Testimony
                if ($row['act_region'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>View Regional Store </td>
                  <td>
                    <a href="php/action.php?region=act_region&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### Action On Teen Testimony
                if ($row['acc_region'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>View Health Store </td>
                  <td>
                    <a href="php/action.php?Accessregion=acc_region&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### Action On Teen Testimony
                if ($row['acc_nation'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>View All blood </td>
                  <td>
                    <a href="php/action.php?AccessNation=acc_nation&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                 <?php // ####### access on blood utility
                if ($row['acc_utility'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>View blood utility </td>
                  <td>
                    <a href="php/action.php?utilityAccess=acc_utility&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### access on blood utility
                if ($row['acc_donor'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access blood Donor </td>
                  <td>
                    <a href="php/action.php?DonorAccess=acc_donor&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### access on blood utility
                if ($row['acc_request'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>View blood request </td>
                  <td>
                    <a href="php/action.php?requestAccess=acc_request&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### access on blood utility
                if ($row['acc_bloodstore'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access blood Store </td>
                  <td>
                    <a href="php/action.php?StoreAccess=acc_bloodstore&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### access on blood utility
                if ($row['acc_heathstore'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access Health blood Store </td>
                  <td>
                    <a href="php/action.php?HealthAccess=acc_heathstore&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### Action On Teen Users
                if ($row['add_user'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Add New Users</td>
                  <td>
                    <a href="php/action.php?privilege=add_user&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

              
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </section>