    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Enter the new Quantity of Blood Type</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="home.php?view=pub"><button type="button" class="btn btn-default btn-sm active"><i class=" text-green">view store</i>
                  </button></a>
                  
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                      <div class="col-md-8">
                        <input  class="form-control" name="username" id="name" type="hidden" value="<?php echo $row_user['user_name']; ?>">
                      </div>
                    </div>
                   

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputLastName">Blood Code</label>
                          <input type="text" name="Bloodcode" class="form-control" placeholder="Enter the Blood code...." required>
                        </div>
                        <div class="col-md-8">
                          <label for="exampleInputLastName">Blood Type</label>
                          <select name="Bloodtype" class="form-control" required>
                            <option selected disabled>--select--</option>
                            <option >A</option>
                            <option >B</option>
                            <option >AB</option>
                            <option >O</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputLastName"> Blood Quantity</label>
                          <input type="number" class="form-control" name="Quantity" >
                        </div>
                        <div class="col-md-8">
                          <label for="exampleInputLastName"></label>
                          <button  name = "newpub" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>


                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>