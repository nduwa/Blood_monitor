        <section class="col-xs-3">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Access Autorisation</h3>
            </div>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <?php // ####### Access to Donors Activities
                if ($row['acc_donor'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access to Donors Activities</td>
                  <td>
                    <a href="php/action.php?privilege=acc_donor&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### Access to users Activities
                if ($row['acc_users'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access to users Activities</td>
                  <td>
                    <a href="php/action.php?privilege=acc_users&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                 <?php // ####### Access to Visitation Activities
                if ($row['acc_visitation'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access to Visitor Activities</td>
                  <td>
                    <a href="php/action.php?privilege=acc_visitation&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>


                <?php // ####### Access to Mail
                if ($row['acc_mail'] == 0) { 
                  $status = "OFF"; $add_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $add_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access to Contact Mail</td>
                  <td>
                    <a href="php/action.php?privilege=acc_mail&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $add_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>
                  <?php
                   if ($row['user_access'] == 0) {
                     $statuse = "OFF"; $act_sts = "fa-toggle-off"; $acts = 1;
                  }else{
                    $statuse = "ON"; $act_sts = "fa-toggle-on text-blue"; $acts = 0;
                  }
                  ?>
                <tr>
                  <td>Change User Access</td>
                  <td>
                    <a href="php/action.php?usr_acc=user_access&status=<?php echo $acts; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_sts; ?>"></i> <?php echo $statuse; ?>
                    </a>
                  </td>
                </tr>

              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </section>