<?php
if(isset($_REQUEST['ncbt_health_store_Details'])) {
  $id = $_REQUEST['ncbt_health_store_Details'];
  $sql = "SELECT * FROM distributed_blood INNER JOIN teen_posters ON distributed_blood.request_id = teen_posters.post_id WHERE distributed_blood.request_id = '$id'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">This view show the Blood Quantity of <span class="badge badge-info"><h5><?php echo $row['post_name']; ?></h5></span> </h3>
          
              

              
            </div>

            <?php
          $sql = "SELECT * FROM distributed_blood JOIN blood_type ON distributed_blood.blood_id = blood_type.type_id WHERE distributed_blood.request_id = '$id' ";
            $result = $conn->query($sql);
            echo $conn->error;
            if ($result->num_rows > 0) {
            ?>

            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>

                  <th>Blood Type</th>
                  <th>Quantity</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  
                ?>
                <tr>
                    
                    <td>
                    <?php echo $row['type_name']; ?></td>
                    <td><b style="color: green;">
                    <?php echo $row['quantity']; ?> Bath</b></td>
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Blood Quantity Available!";
            }} ?>
          </div>
          <!-- /.box -->

        </section>
         <?php
          $sql = "SELECT * FROM  blood_type";
          $result = $conn->query($sql);
          $data = $result->num_rows;
          ?>

        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
                   <!-- block -->
                <div class="block">
                    <div class="navbar navbar-inner block-header">
                        <div class="muted pull-left"><h3>This view shows how the blood are served to the patient in health support</h3></div>
                        <div class="pull-right"><span class="badge badge-info"><?php echo $data; ?></span>

                        </div>
                    </div>
                    <div class="block-content collapse in">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Blood Type</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $n=1;
                                while ($row = $result->fetch_assoc()) {
                                  $bid = $row['type_id'];                                  

                                $sqls = "SELECT * FROM served_blood INNER JOIN blood_type ON served_blood.blood_type_id = blood_type.type_id WHERE served_blood.served_by = '$id' AND served_blood.blood_type_id = '$bid'";
                                $results = $conn->query($sqls);
                                echo $conn->error;
                                $sum = 0;
                                while ($rows = $results->fetch_assoc()) {
                                  $out = $rows['blood_quantity'];
                                  $sum+=$out;
                                }
                               $name = $row['type_name'];
                               $num = $n++;
                               ?>
                                
                                <tr>
                                    <td><?php echo $num;?></td>
                                    <td><?php echo $name; ?></td>
                                    <td><b style="color: green;"><?php echo $sum; ?> Sac</b></td>
                                    <!-- <td><a href="home.php?view=health_detail&blood_type_Details=<?php// echo $id;?>">Details...</a>
                                    </td> -->
                                </tr>
                              
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
                            <!-- /block -->
          </div>
          <!-- /.box -->


        </section>

      </div>
    </section>
  </div>