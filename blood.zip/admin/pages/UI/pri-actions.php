        <section class="col-xs-4">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Action Autorisation <i class="fa fa-exclamation-circle" title="Display on whole, Delete, Hide Form Whole"></i></h3>
            </div>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
          

                <?php // ####### Action On Teen Users
                if ($row['act_user'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Users Access System</td>
                  <td>
                    <a href="php/action.php?additional=act_user&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                <?php // ####### Action On blood models
                if ($row['act_model'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Change blood model</td>
                  <td>
                    <a href="php/action.php?model_act=act_model&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                  <?php // ####### Action On blood models
                if ($row['act_type'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Change blood type</td>
                  <td>
                    <a href="php/action.php?type_act=act_type&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                  <?php // ####### Action On blood distributor location
                if ($row['act_location'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>make Change on location</td>
                  <td>
                    <a href="php/action.php?location=act_location&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                  <?php // ####### Action On access the blood  location
                if ($row['view_location'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Access on blood location</td>
                  <td>
                    <a href="php/action.php?locationView=view_location&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>

                  <?php // ####### Action On access the blood  location
                if ($row['act_utility'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; }
                    ?>
                <tr>
                  <td>Make change on Blood utility</td>
                  <td>
                    <a href="php/action.php?utility=act_utility&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>


              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </section>