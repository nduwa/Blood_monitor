  <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_place";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $label = "Add Post:";
      $act = "new_level";
      $name = "";
      $id = ""; 
    }
    ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">


        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List of User Level</h3>
              
              <?php if ($row_post['add_posts'] == 1) { ?>
              <div class="pull-right">
                <form action="php/action.php" method="post">
                  <label><?php echo $label; ?></label>
                  <input type="text" name="post" value="<?php echo $name; ?>" placeholder="New Post.." required>
                  <button type="submit" name="<?php echo $act; ?>" value="<?php echo $id; ?>">
                    <i class="fa fa-save text-blue"></i></button>
                </form>
              </div>
              <?php } ?>
              
            </div>

            <?php
            $sql = "SELECT * FROM places ORDER BY place_name ASC";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Psot Title</th>
                  <th class="pull-right">Action</th>
                </tr>
                <?php
                $n = 1;
                while ($row = $result->fetch_assoc()) {
                ?>
                <tr>
                  <td><?php echo $n; ?></td>
                  <td><?php echo $row['place_name']; ?></td>
                  <td class="pull-right">
                    <?php if ($row_post['act_posts'] == 1) { ?>
                    <a href="home.php?view=user_access&edit=<?php echo $row['place_name']; ?>&id=<?php echo $row['place_id']; ?>" class="btn-sm bg-green">
                    <i class="fa fa-edit"></i> Edit</a><?php } ?>
                    <?php if ($row_post['user_access'] == 1) { ?>
                    <a href="home.php?view=UserAccess&id=<?php echo $row['place_id']; ?>" class="btn-sm bg-yellow">
                      <i class="fa fa-gears"></i> Privilege</a><?php } ?>
                  </td>
                </tr>
                <?php $n++; } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Post available!";
            } ?>
          </div>
          <!-- /.box -->

        </section>
        <div class="col-md-6">
          <div class="box box-solid">
            <div class="box-header with-border">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                        The user Access on the system
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse in">
                    <div class="box-body">
                      <h4>This view is used to set the access to the user according to the level of working  if  is NCBT, RCBT and HEALTH all those main distributor has the different employees.<br><br> The Access is seted according to the <b>Admin</b> and <b>Worker.</b></h4> 
                    </div>
                  </div>
                </div>

      </div>
    </section>
  </div>