    <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_post";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $label = "Add Post:";
      $act = "new_post";
      $name = "";
      $id = ""; 
    }
    ?>

    <?php
    $post_id = $_REQUEST['id'];
    $sql = "SELECT * FROM user_privilegie WHERE place_id = '$post_id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    ?>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
<!-- ########################### Privileges About Giving Privileges ########################## -->

<!-- ################## Privileges about Actions "Actions, Delete, Stop,.." ################# -->
<?php include('pages/UI/pri-actions.php'); ?>

<!-- ############################## Privileges about Addition ############################## -->
<?php include('pages/UI/pri-addition.php'); ?>
<!-- ############################## Privileges about Access ############################## -->
<?php //include('pages/UI/pri-access.php'); ?>


      </div>
    </section>
  </div>