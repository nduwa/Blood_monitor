
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->

    <?php
    $sql = "SELECT * FROM teen_posters WHERE post_name LIKE 'RCBT%'";
    $result = $conn->query($sql);
    $data = $result->num_rows;
    ?>
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
                   <!-- block -->
                <div class="block">
                    <div class="navbar navbar-inner block-header">
                        <div class="muted pull-left"><h4>List of Regional Center Blood Transfusion</h4></div>
                        <div class="pull-right"><span class="badge badge-info"><?php echo $data; ?></span>

                        </div>
                    </div>
                    <div class="block-content collapse in">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Region Name</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $n=1;
                                while ($row = $result->fetch_assoc()) {
                                  $id = $row['post_id'];
                                $sqls = "SELECT * FROM bloodstore WHERE username = '$id'";
                                $results = $conn->query($sqls);
                                $datas = $results->num_rows;
                                $sum = 0;
                                while ($rows = $results->fetch_assoc()) {
                                  $out = $rows['bl_qntes'];
                                  $sum+=$out;
                                }
                               $name = $row['post_name'];
                               $num = $n++;
                               ?>
                                
                                <tr>
                                    <td><?php echo $num;?></td>
                                    <td><?php echo $name; ?></td>
                                    <td><b style="color: green;"><?php echo $sum; ?> Bath</b></td>
                                    <td><a href="home.php?view=wast&Details=<?php echo $id;?>">Details...</a>
                                    </td>
                                </tr>
                              
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
                            <!-- /block -->
          </div>
          <!-- /.box -->


        </section>


          

      </div>
    </section>
  </div>