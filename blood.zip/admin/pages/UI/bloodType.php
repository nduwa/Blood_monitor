    <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_type";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $label = "New Blood type:";
      $act = "new_type";
      $name = "";
      $id = ""; 
    }
    ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List of Blood Type</h3><br>
              
              <?php if ($rows['act_type'] == 1) { ?>
              <div class="pull-right">
                <form action="php/action.php" method="post">
                  <label><?php echo $label; ?></label>
                  <input type="text" name="post" value="<?php echo $name; ?>" placeholder="New type of blood.." required>
                  <button type="submit" name="<?php echo $act; ?>" value="<?php echo $id; ?>">
                    <i class="fa fa-save text-blue">save</i></button>
                </form>
              </div>
              <?php } ?>
              
            </div>

            <?php
            $sql = "SELECT * FROM blood_type ORDER BY type_name ASC";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Blood code</th>
                  <th>Blood Type</th>
                </tr>
                <?php
                $n = 1;
                while ($row = $result->fetch_assoc()) {
                ?>
                <tr>
                  <td><?php echo $n; ?></td>
                  <td><?php echo $row['type_code']; ?></td>
                  <td><?php echo $row['type_name']; ?></td>
                  <td class="pull-right">
                    <?php if ($rows['act_type'] == 1) { ?>
                    <a href="home.php?view=blood_type&edit=<?php echo $row['type_name']; ?>&id=<?php echo $row['type_id']; ?>" class="btn-sm bg-green">
                    <i class="fa fa-edit"></i> Edit</a><?php } ?>
                    
                    <?php if ($rows['act_type'] == 1) { ?>
                    <a href="php/action.php?delpost=<?php echo $row['type_id']; ?>" class="btn-sm bg-red">
                    <i class="fa fa-trash"></i> Delete</a><?php } ?>
                  </td>
                </tr>
                <?php $n++; } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Post available!";
            } ?>
          </div>
          <!-- /.box -->

        </section>

                <div class="col-md-6">
          <div class="box box-solid">
            <div class="box-header with-border">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                        There are eight common blood types and many rare ones.
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse in">
                    <div class="box-body">
                      <h4>
                      Blood types are determined by the presence or absence of certain antigens – substances that can trigger an immune response if they are foreign to the body.  Since some antigens can trigger a patient's immune system to attack the transfused blood, safe blood transfusions depend on careful blood typing and cross-matching.<br><br>In addition to the A and B antigens, there is a protein called the Rh factor, which can be either present (+) or absent (–), creating the 8 most common blood types <b>(A+, A-, B+, B-, O+, O-, AB+, AB-)</b>.
                    </h4>
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

      </div>
    </section>
  </div>