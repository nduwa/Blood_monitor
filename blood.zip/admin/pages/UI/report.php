
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->

    <?php
    $sql = "SELECT * FROM  blood_type";
    $result = $conn->query($sql);
    $data = $result->num_rows;
    ?>
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
                   <!-- block -->
                <div class="block">
                    <div class="navbar navbar-inner block-header">
                        <div class="muted pull-left"><h4>This view shows how the blood are served to the patient in health support</h4></div>
                        <div class="pull-right"><span class="badge badge-info"><?php echo $data; ?></span>

                        </div>
                    </div>
                    <div class="block-content collapse in">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Blood Type</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $n=1;
                                while ($row = $result->fetch_assoc()) {
                                  $id = $row['type_id'];
                                $sqls = "SELECT * FROM served_blood WHERE blood_type_id = '$id' AND served_by = '" . $row_user['user_title']. "'";
                                $results = $conn->query($sqls);
                                $sum = 0;
                                while ($rows = $results->fetch_assoc()) {
                                  $out = $rows['blood_quantity'];
                                  $sum+=$out;
                                }
                               $name = $row['type_name'];
                               $num = $n++;
                               ?>
                                
                                <tr>
                                    <td><?php echo $num;?></td>
                                    <td><?php echo $name; ?></td>
                                    <td><b style="color: green;"><?php echo $sum; ?> Bath</b></td>
                                    <td><a href="home.php?view=health_detail&blood_type_Details=<?php echo $id;?>">Details...</a>
                                    </td>
                                </tr>
                              
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
                            <!-- /block -->
          </div>
          <!-- /.box -->


        </section>

        <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">This view shows how the blood are in the Health Facilities in the system</h3>
              
              <h3></h3>
            <?php
            //if (isset($_POST['view'])) {
             
       
            $sql = "SELECT * FROM tbl_distributed_blood_backup JOIN teen_posters ON tbl_distributed_blood_backup.back_distributor = teen_posters.post_id  JOIN blood_type ON tbl_distributed_blood_backup.backup_blood_id = blood_type.type_id WHERE tbl_distributed_blood_backup.backup_requestor = '" . $row_user['user_title']. "' order by tbl_distributed_blood_backup.dis_backup_id DESC ";
            $result = $conn->query($sql);
            if ($result) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  
                  <th>Blood Type</th>
                  <th>Quantity</th>
                  <th>Destination</th>
                  <th>Date</th>
                  <!-- <th>Done By</th> -->
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  $quantity = $row['backup_quantity']; 
                  
                    $time = $row['backup_date'];
                    $d = strtotime($time);
                ?>
                <tr>
                  <td><?php echo $row['type_name']; ?></td>
                  <td><b style="color: green;"><?php echo $quantity; ?> Sac</b></td>
                  <td><?php echo $row['post_name']; ?></td>
                  <td><?php echo date("d M.Y h:m:i", $d); ?></td>
                 <!-- <td><?php //echo $row_user['user_name']; ?></td>--->
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else { 
                
                    echo "NO DATA RELATED TO YOUR STORE";
           } ?>
          </div>
      
        
        </section>


          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

      </div>
    </section>
  </div>