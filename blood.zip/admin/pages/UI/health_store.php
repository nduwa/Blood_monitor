      <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_post";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $labels = "Select Blood Type:";
      $label = "Blood Quantity:";
      $labe = "Blood Utility:";
      $act = "newpub";
      $name = "";
      $id = ""; 
    }
    ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-9">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">The Health Center Blood Store of Usable</h3>
              <h3></h3>
              <h3><a href="home.php?ADD=new_request"><button type="button" class="btn btn-primary">Request blood to get the store </button></a></h3>

            <?php
            $sql = "SELECT * FROM distributed_blood INNER JOIN blood_type ON distributed_blood.blood_id = blood_type.type_id WHERE request_id = '" . $row_user['user_title']. "'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  <th>#</th>
                  <th>Blood ID</th>
                  <th>Blood Type</th>
                  <th>Quantity</th>
                  <th class="pull-right">Action</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  $quantity = $row['quantity']; 
                ?>
                <tr>
                  <td><a href="php/action.php?pudel=<?php echo $row['distributed_id']; ?>" class="btn-sm bg-red">
                    <i class="fa fa-trash"></i></a></td>
                    <td>
                    <?php echo $row['type_code']; ?></td>
                    <td>
                    <?php echo $row['type_name']; ?></td>
                    <td><b style="color: green;">
                    <?php echo $quantity; ?> Bath</b></td>
                  <td class="pull-right">
                    
                    <a href="home.php?ADD=bloodreduce&bloodReduction=<?php echo $row['distributed_id'];?>" class="btn-sm bg-blue">
                    <i class="fa fa-edit"></i> Serve</a>
                    <a href="home.php?ADD=bloodrequest&bloodRequest=<?php echo $row['distributed_id'];?>" class="btn-sm bg-blue">
                    <i class="fa fa-edit"></i> Request</a>
                    
                  </td>

                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else { 
                
                    echo "NO DATA RELATED TO YOUR STORE";
           } ?>
          </div>
      

        </section>

      </div>
    </section>
  </div>