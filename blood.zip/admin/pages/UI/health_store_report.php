<?php
if(isset($_REQUEST['health_store_Details'])) {
  $id = $_REQUEST['health_store_Details'];
  $sql = "SELECT * FROM distributed_blood INNER JOIN teen_posters ON distributed_blood.request_id = teen_posters.post_id WHERE distributed_blood.request_id = '$id'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Blood Quantity of <?php echo $row['post_name']; ?></h3>
              <h3></h3>
              

              
            </div>

            <?php
          $sql = "SELECT * FROM distributed_blood JOIN blood_type ON distributed_blood.blood_id = blood_type.type_id WHERE distributed_blood.request_id = '$id' ";
            $result = $conn->query($sql);
            echo $conn->error;
            if ($result->num_rows > 0) {
            ?>

            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>

                  <th>Blood Type</th>
                  <th>Quantity</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  
                ?>
                <tr>
                    
                    <td>
                    <?php echo $row['type_name']; ?></td>
                    <td><b style="color: green;">
                    <?php echo $row['quantity']; ?> Bath</b></td>
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Blood Quantity Available!";
            }} ?>
          </div>
          <!-- /.box -->

        </section>

      </div>
    </section>
  </div>