    <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_post";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $label = "Add Post:";
      $act = "new_post";
      $name = "";
      $id = ""; 
    }
    ?>

    <?php
    $post_id = $_REQUEST['id'];
    $sql = "SELECT * FROM teen_privileges WHERE post_id = '$post_id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    ?>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
<!-- ########################### Privileges About Giving Privileges ########################## -->

        <section class="col-xs-3">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Privileges Autorisation</h3>              
            </div>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <?php
                if ($row['give_privilege'] == 0) { 
                  $status = "OFF"; $act_st = "fa-toggle-off"; $act = 1; }
                else { 
                  $status = "ON"; $act_st = "fa-toggle-on text-blue"; $act = 0; 
                }
                 ?>
                <tr>
                  <td>Change Privileges</td>
                  <td>
                    <a href="php/action.php?privilege=give_privilege&status=<?php echo $act; ?>&poste=<?php echo $post_id; ?>">
                      <i class="fa <?php echo $act_st; ?>"></i> <?php echo $status; ?>
                    </a>
                  </td>
                </tr>
                
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </section>

<!-- ############################## Privileges about Access ############################## -->
<?php include('pages/UI/pri-access.php'); ?>

      </div>
    </section>
  </div>