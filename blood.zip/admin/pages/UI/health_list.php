<?php
if(isset($_REQUEST['list_of_health'])) {
  $tid = $_REQUEST['list_of_health'];
  $sql = "SELECT * FROM teen_posters  WHERE post_name LIKE 'Health%' AND region_id = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
  <?php
            $sql = "SELECT * FROM teen_posters WHERE post_name LIKE 'Health%' AND region_id = '$tid'";
            $result = $conn->query($sql);
            $data = $result->num_rows;
            ?>
  <section class="content">
      <!-- Small boxes (Stat box) -->        
        <section class="col-xs-6 ">
          <div class="box">
            <div class="box-header">
                   <!-- block -->
                <div class="block">
                    <div class="navbar navbar-inner block-header">
                        <div class="muted pull-left">List of Regional Blood Center</div>
                        <div class="pull-right"><span class="badge badge-info"><?php echo $data; ?></span>

                        </div>
                    </div>
                    <div class="block-content collapse in">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Health Name</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $n=1;
                                while ($row = $result->fetch_assoc()) {
                                $id = $row['post_id'];
                                $sqls = "SELECT * FROM distributed_blood WHERE request_id = '$id'";
                                $results = $conn->query($sqls);
                                $datas = $results->num_rows;
                                $sum = 0;
                                while ($rows = $results->fetch_assoc()) {
                                  $out = $rows['quantity'];
                                  $sum+=$out;
                                }
                               $name = $row['post_name'];
                              
                               $num = $n++;
                               ?>
                                <tr>
                                    <td><?php echo $num;?></td>
                                    <td><?php echo $name; ?></td>
                                    <td><b style="color: green;">
                                        <?php echo $sum; ?> Bath</b>
                                      </td>
                                    <td><a href="home.php?view=health_store&health_store_Details=<?php echo $id;?>">Details...</a>
                                    </td>
                                </tr>
                                <?php }?>
                            </tbody>
                        </table>
                    </div>
                </div>
                            <!-- /block -->
          </div>
          <!-- /.box -->

        </section>
  </div>