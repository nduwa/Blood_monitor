    <?php
    if (isset($_REQUEST['edit'])) {
      $label = " Location:";
      $label1 = "Station:";
      $act = "update_post";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $label = "Location:";
      $label1 = "Distributor:";
      $label2 = "longitude:";
      $label3 = "latitude:";
      $act = "new_post";
      $name = "";
      $id = ""; 
    }
    ?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-xs-7 ">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List of Blood Center Tansfusion Location </h3>
              <h3></h3>
              
              <?php if ($rows['act_location'] == 1) { ?>
              <div class="pull-right">
                <form action="php/action.php" method="post">
                  <label><?php echo $label; ?></label>
                  <?php $sql = "SELECT * FROM tbl_regions";
                            $result = $conn->query($sql); ?>
                        <select  id="regions" name="regions"  >
                          <option disabled="disabled" selected="selected">Select</option>
                          <?php while($row = $result->fetch_assoc()){ ?>
                          <option value="<?php echo $row['region_id']; ?>"><?php echo $row['region_name']; ?></option>
                          <?php } ?>
                        </select> 
                  <label><?php echo $label1; ?></label>      
                  <input type="text" name="post" value="<?php echo $name; ?>" placeholder="New distributor.." required><hr>
                  <label><?php echo $label2; ?></label>      
                  <input type="number" min="0" name="longitude" value="<?php echo $name; ?>" placeholder="New longitude.." required>
                  <label><?php echo $label3; ?></label>      
                  <input type="number" min="0" name="latitude" value="<?php echo $name; ?>" placeholder="New latitude.." required>
                  <button type="submit" name="<?php echo $act; ?>" value="<?php echo $id; ?>">
                    <i class="fa fa-save text-blue"></i></button>
                </form>
              </div>
              <?php } ?>
              
            </div>

            <?php
            $sql = "SELECT * FROM teen_posters JOIN tbl_regions ON teen_posters.region_id = tbl_regions.region_id ORDER BY post_name ASC";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>

            <!-- /.box-header -->
            <div class="box-body no-padding">
              <table class="table table-condensed">
                <tr>
                  <th style="width: 10px">#</th>
                  <th>Location Name</th>
                 
                </tr>
                <?php
                $n = 1;
                while ($row = $result->fetch_assoc()) {
                ?>
                <tr>
                  <td><?php echo $n; ?></td>
                  <td><?php echo $row['post_name']; ?></td>
                  <td><?php echo $row['region_name']; ?></td>
                  <td class="pull-right">
                    <?php if ($rows['act_location'] == 1) { ?>
                    <a href="home.php?view=teen_post&edit=<?php echo $row['post_name']; ?>&id=<?php echo $row['post_id']; ?>" class="btn-sm bg-green">
                    <i class="fa fa-edit"></i> Edit</a><?php } ?>
                    <?php if ($rows['act_location'] == 1) { ?>
                    <a href="php/action.php?delpost=<?php echo $row['post_id']; ?>" class="btn-sm bg-red">
                    <i class="fa fa-trash"></i> Delete</a><?php } ?>
                  </td>
                </tr>
                <?php $n++; } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else {
              echo "There is no Post available!";
            } ?>
          </div>
          <!-- /.box -->


        </section>
         <div class="col-md-5">
          <div class="box box-solid">
            <div class="box-header with-border">
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="box-group" id="accordion">
                <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                <div class="panel box box-primary">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                        National Blood Distribution Location Instruction
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse in">
                    <div class="box-body">
                      <h4>
                      This view shows the list of blood distributor in the country, on this we find the Health centers, the Regional center blood transfusion and National center blood transfusion as the own of the system.<br><br> 
                      <b>Note:</b> To insert a new distributor use the following keyword<br>
                      <br>1. <b>RCBT-</b> if the distributor is regional center blood transfusion. 
                      <b>Example: RCBT-Kigali</b><br>
                      <br>2. <b>Health-</b> if the distributor is health center.
                      <b>Example: Health-CHUK</b><br>  
                    </h4>
                    </div>
                  </div>
                </div>
                
               
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

      </div>
    </section>
  </div>