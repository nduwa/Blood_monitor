<?php
if(isset($_REQUEST['blood_wast_Details'])) {
  $tid = $_REQUEST['blood_wast_Details'];
  $sql = "SELECT * FROM tbl_bloodstore_backup JOIN blood_type ON tbl_bloodstore_backup.backup_blood_type = blood_type.type_id WHERE tbl_bloodstore_backup.backup_blood_type = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-7">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">This view shows how the blood are entered in the system</h3>
              
              <h3></h3>
            <?php
            //if (isset($_POST['view'])) {
             
       
            $sql = "SELECT * FROM tbl_bloodstore_backup JOIN blood_type ON tbl_bloodstore_backup.backup_blood_type = blood_type.type_id WHERE tbl_bloodstore_backup.backup_utilite = 2 AND tbl_bloodstore_backup.backup_blood_type = '$tid' AND  tbl_bloodstore_backup.bachup_username = '" . $row_user['user_title']. "' order by tbl_bloodstore_backup.backup_id DESC ";
            $result = $conn->query($sql);
            if ($result) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  
                  <th>Blood Type</th>
                  <th>Quantity</th>
                  <th>Season</th>
                  <th>Reason</th>
                  <th>Date</th>
                  <th>Done By</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  $quantity = $row['backup_quantity']; 
                  
                    $time = $row['backup_date']. ''.$row['backup_time'];
                    $d = strtotime($time);
                ?>
                <tr>
                  <td><?php echo $row['type_name']; ?></td>
                  <td><b style="color: red;"><?php echo $quantity; ?> Bath</b></td>
                  <td><?php echo $row['backup_season']; ?></td>
                  <td><?php echo $row['backup_reason']; ?></td>
                  <td><?php echo date("d M.Y h:m:i", $d); ?></td>
                  <td><?php echo $row_user['user_name']; ?></td>
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else { 
                
                    echo "NO DATA RELATED TO YOUR STORE";
           } ?>
          </div>
      
        
        </section>
       
     

      
    </section>
  </div>