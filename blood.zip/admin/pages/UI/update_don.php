<?php
$code = "";
$type = "";
$action = "edit_Donor";
if(isset($_REQUEST['edit'])) {
  $tid = $_REQUEST['edit'];
  $sql = "SELECT * FROM donors WHERE don_id = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  $code = $row['don_name'];
  $type = $row['don_email'];
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Blood Request format</h3>

              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="home.php?view=pub"><button type="button" class="btn btn-default btn-sm active"><i class=" text-green"> view store</i>
                  </button></a>
                  
                </div>
              </div>
            </div>
          <div class="box box-info">
            <div class="box-body">
             <!-- chat item -->
              <div class="card card-register mx-auto mt-5">
                <div class="card-body">
                  <form action="php/action.php" method="post" enctype="multipart/form-data">

                    <div class="form-group">
                      <div class="col-md-8">
                        <input  class="form-control" name="username" id="name" type="hidden" value="<?php echo $row_user['user_name']; ?>">
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Blood Code</label>
                          <input class="form-control" name="bl_code" type="text" value="<?php echo $code; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputLastName">Blood Type</label>
                          <input class="form-control" type="text" name="bl_type" value="<?php echo $type; ?>">
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Blood Quantity</label>
                          <input type="number" class="form-control" name="Quantity" placeholder="Enter the Blood Quantity..."> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <label for="exampleInputName">Request Blood Comment</label>
                          <textarea class="form-control" name="Comment" placeholder="Enter the Blood Quantity..."> </textarea> 
                        </div>
                      </div>
                    </div>

                    <div class="form-group">
                      <div class="form-row">
                        <div class="col-md-8">
                          <br />
                          <button  name = "<?php echo $action; ?>" value = "<?php echo $tid; ?>" class="btn btn-success btn-block">Save</button>
                        </div>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
            </div>
              
              <!-- /.item -->
            </div>
            </div>
          </div>
        </section>
      </div>
    </section>