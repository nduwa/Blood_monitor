<?php
if(isset($_REQUEST['blood_type_Details'])) {
  $tid = $_REQUEST['blood_type_Details'];
  $sql = "SELECT * FROM served_blood JOIN blood_type ON served_blood.blood_type_id = blood_type.type_id WHERE served_blood.blood_type_id = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-9">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">This View shows the details of how the Health Center serve the blood to the patient</h3>
             
              <h3></h3>
            <?php
            //if (isset($_POST['view'])) {
             
       
            $sql = "SELECT * FROM served_blood  JOIN blood_type ON served_blood.blood_type_id = blood_type.type_id WHERE served_blood.blood_type_id = '$tid'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  <th>Blood Type</th>
                  <th>Quantity</th>
                  <th>Name</th>
                  <th >Reason</th>
                  <th>Date</th>
                  <th>Done By</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  $quantity = $row['blood_quantity']; 
                  
                    $time = $row['served_date'];
                    $d = strtotime($time);
                ?>
                <tr>
                  <td><?php echo $row['type_name']; ?></td>
                  <td><b><?php echo $quantity; ?>Bath</b></td>
                  <td><?php echo $row['patient_name']; ?></td>
                  <td><?php echo $row['reason']; ?></td>
                  <td><?php echo date("d M.Y", $d); ?></td>
                  <td><?php echo $row['serve_user']; ?></td>
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else { 
                
                    echo "NO DATA RELATED TO YOUR STORE";
           } ?>
          </div>
      

        </section>

      </div>
    </section>
  </div>