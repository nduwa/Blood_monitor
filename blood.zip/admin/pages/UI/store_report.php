<?php
if(isset($_REQUEST['blood_entered_Details'])) {
  $tid = $_REQUEST['blood_entered_Details'];
  $sql = "SELECT * FROM tbl_bloodstore_backup JOIN blood_type ON tbl_bloodstore_backup.backup_blood_type = blood_type.type_id WHERE tbl_bloodstore_backup.backup_blood_type = '$tid'";
  $result = $conn->query($sql);
  $row = $result->fetch_assoc();
  //$action = "update_testimony";
}
?>
    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">This view shows how the blood are entered in the system</h3>
              
              <h3></h3>
            <?php
            //if (isset($_POST['view'])) {
             
       
            $sql = "SELECT * FROM tbl_bloodstore_backup JOIN blood_type ON tbl_bloodstore_backup.backup_blood_type = blood_type.type_id WHERE tbl_bloodstore_backup.backup_utilite = 1 AND tbl_bloodstore_backup.backup_blood_type = '$tid' AND  tbl_bloodstore_backup.bachup_username = '" . $row_user['user_title']. "' order by tbl_bloodstore_backup.backup_id DESC ";
            $result = $conn->query($sql);
            if ($result) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  
                  <th>Blood Type</th>
                  <th>Quantity</th>
                  <th>Season</th>
                  <th>Date</th>
                  <!-- <th>Done By</th> -->
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  $quantity = $row['backup_quantity']; 
                  
                    $time = $row['backup_date']. ''.$row['backup_time'];
                    $d = strtotime($time);
                ?>
                <tr>
                  <td><?php echo $row['type_name']; ?></td>
                  <td><b style="color: green;"><?php echo $quantity; ?> Bath</b></td>
                  <td><?php echo $row['backup_season']; ?></td>
                  <td><?php echo date("d M.Y h:m:i", $d); ?></td>
                  <!-- <td><?php //echo $row_user['user_name']; ?></td> -->
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else { 
                
                    echo "NO DATA RELATED TO YOUR STORE";
           } ?>
          </div>
      
        
        </section>
       
       <section class="col-sm-6">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">This view shows how the blood are distributed to the Health Facilities in the system</h3>
              
              <h3></h3>
            <?php
            //if (isset($_POST['view'])) {
             
       
            $sql = "SELECT * FROM tbl_distributed_blood_backup JOIN teen_posters ON tbl_distributed_blood_backup.backup_requestor = teen_posters.post_id  JOIN blood_type ON tbl_distributed_blood_backup.backup_blood_id = blood_type.type_id WHERE tbl_distributed_blood_backup.backup_blood_id = '$tid' AND  tbl_distributed_blood_backup.back_distributor = '" . $row_user['user_title']. "' order by tbl_distributed_blood_backup.dis_backup_id DESC ";
            $result = $conn->query($sql);
            if ($result) {
            ?>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-condensed">
                <tr>
                  
                  <th>Blood Type</th>
                  <th>Quantity</th>
                  <th>Destination</th>
                  <th>Date</th>
                  <!-- <th>Done By</th> -->
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  $quantity = $row['backup_quantity']; 
                  
                    $time = $row['backup_date'];
                    $d = strtotime($time);
                ?>
                <tr>
                  <td><?php echo $row['type_name']; ?></td>
                  <td><b style="color: green;"><?php echo $quantity; ?> Bath</b></td>
                  <td><?php echo $row['post_name']; ?></td>
                  <td><?php echo date("d M.Y h:m:i", $d); ?></td>
                 <!-- <td><?php //echo $row_user['user_name']; ?></td>--->
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php } ?>
              </table>
            </div>
            <!-- /.box-body -->
            <?php }
            else { 
                
                    echo "NO DATA RELATED TO YOUR STORE";
           } ?>
          </div>
      
        
        </section>
       
     

      </div>
    </section>
  </div>