    <?php
    if (isset($_POST['search'])) {
      $search = $_POST['search'];
      $search = preg_replace("#[^0-9a-z]#i", "", $search);
    $sql = "SELECT * FROM donors WHERE card_id like '%$search%'";
    $result = $conn->query($sql);
    ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">

        <!-- col-md-3 -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Donors</span>
              <span class="info-box-number"><?php echo $result->num_rows; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <!-- col-md-3 -->
       

      </div>
      <div class="row">

        <?php //include('visitor_aside.php'); ?>
        <!-- /. col-md-3 -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">List of Blood Donors</h3>

              
              <div class="box-tools pull-right">
                <div class="has-feedback">
                  <input type="text" class="form-control input-sm" placeholder="Search Mail">
                  <span class="glyphicon glyphicon-search form-control-feedback"></span>
                </div>
              </div> 
              <!-- /.box-tools -->
            </div>
            
            <!-- /.box-header -->
            <div class="box-body no-padding">
              
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover">
                  <tbody>
                    <?php
                    if ($result->num_rows > 0) { ?>
                    <tr>
                      <th>code</th>
                      <th>code</th>
                      <th>code</th>
                      <th>code</th>
                      <th>code</th>
                    </tr>

                     <?php while($row = $result->fetch_assoc()){ ?>
                  
                    <tr>
                    <td><a href="home.php?ADD=program&pid=<?php echo $row['don_id']; ?>&pedit"><button type="button" class="btn btn-default btn-sm"><i class="fa fa-edit"></i></button></a>
                    </td>
                    <td><?php echo $row['card_id'];?></td>
                    <td><?php echo $row['don_name'].'&nbsp;'.$row['don_lname']; ?></td>
                    <td><?php echo $row['don_email'];?></td>
                    <td><?php echo $row['don_phone'];?></td>
                    <td><?php echo $row['don_address'];?></td>
                    <td><?php echo $row['don_blood_type'];?></td>
                  </tr>
                
                    <?php }
                     }

                    else { ?>
                  <tr>
                    <td colspan="4" align="center">No Donor name exist!</td>
                  </tr>
                    <?php }} ?>
                  </tbody>
                </table>
                <!-- /.table -->
               
              <!-- /.mail-box-messages -->
            </div>
             <div><center>
             <a href="home.php?ADD=donor" class="btn-sm bg-blue">
                    <i class="fa fa-edit"></i> New</a>
           </center>
              </div>

            <!-- /.box-body -->
          </div>
          
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
