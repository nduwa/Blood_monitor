              <div class="active tab-pane" id="settings">
                <form class="form-horizontal" method="POST" action="php/action.php" enctype="multipart/form-data">

                  <div class="form-group">
                    <div class="col-sm-12">
                      <p id="success_para" ></p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">Name</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" placeholder="Name" name="names" value="<?php echo $row_user['user_name']; ?>" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">Email</label>
                    <div class="col-sm-10">
                      <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo $row_user['user_email']; ?>" required>
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Phone</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" placeholder="Phone" name="phone" value="<?php echo $row_user['user_phone']; ?>" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label">Post</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" placeholder="Post" name="post" value="<?php echo $row_user['post_name']; ?>" disabled required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">Change Profile</label>
                    <div class="col-sm-10">
                      <input type="file" class="form-control" name="profile">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">New Password</label>
                    <div class="col-sm-10">
                      <input type="password" class="form-control" placeholder="New Password" name="new_code">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">Current Password</label>
                    <div class="col-sm-10">
                      <input type="password" class="form-control" placeholder="Old Password" name="passcode" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger" name="update_set">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->