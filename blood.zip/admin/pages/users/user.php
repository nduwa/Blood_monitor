    <!-- Main content -->
    <section class="content">
     
      <!-- Main row -->
       <div class="row">
        <div class="col-xs-12">
          <div class="box container">
            <div class="box-header">
              <h3 class="box-title">List of Users Account</h3>
            <?php
            if ($rows['act_user'] == 1){
            ?>
            <div style="margin-left: 90%;margin-top: -1em;">
              <a href="home.php?ADD=user" class="btn-sm bg-blue">
              <i class="fa fa-edit"></i> New</a>
            </div>
            <?php } ?> 
            </div>
           
            <!-- /.box-header -->
            <?php
            $user = $row_user['user_title'];
              $sql = "SELECT * FROM users JOIN teen_posters ON users.user_title = teen_posters.post_id WHERE user_id <> '$teen_id' ORDER BY post_name ASC";
              $result = $conn->query($sql);
            ?>
            <div class="box-body table-responsive no-padding">
              <table id="table" class="table table-borderd">
                <thead>
                <tr>
                  <th><i class="fa fa-users text-primary"></i> Full Names</th>
                  <th><i class="fa fa-phone text-primary"></i> Contact</th>
                  <th><i class="fa fa-gears text-primary"></i> Post</th>
                </tr>
                </thead>
                <tbody>
                  <?php while($row = $result->fetch_assoc()){
                    if ($row['post_id'] == $user) {
                    $status = $row['user_status'];
                    $users_id = $row['user_id'];
                    $admission = $row['user_place'];
                    if ($status == 0) { 
                      $btn = "btn-warning";
                      $act = "New User";
                      $li = "<li><a href='php/action.php?usr_id=".$users_id."&act=1'>Access</a></li>";
                      $li .= "<li><a href='php/action.php?usr_id=".$users_id."&act=2'>Stop Access</a></li>"; }
                    else if ($status == 1) {
                      $btn = "btn-primary";
                      $act = "Working";
                      $li = "<li><a href='php/action.php?usr_id=".$users_id."&act=2'>Stop Access</a></li>"; }
                    else { 
                      $btn = "btn-danger";
                      $act = "Stoped";
                      $li = "<li><a href='php/action.php?usr_id=".$users_id."&act=1'>Access</a></li>"; }
                      if ($admission == 1) {
                        $btns = "btn-default";
                        $acts = "NCBT-Admin";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=2'>Worker</a></li>";
                      }elseif($admission == 2){
                        $btns = "btn-default";
                        $acts = "NCBT-Worker";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=1'>Admin</a></li>";
                      }elseif($admission == 3){
                        $btns = "btn-default";
                        $acts = "RCBT-Admin";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=4'>Admin</a></li>";
                      }elseif($admission == 4){
                        $btns = "btn-default";
                        $acts = "RCBT-Worker";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=3'>Admin</a></li>";
                      }elseif($admission == 5){
                        $btns = "btn-default";
                        $acts = "Health-Admin";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=6'>Admin</a></li>";
                      }elseif($admission == 6){
                        $btns = "btn-default";
                        $acts = "Health-Worker";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=5'>Admin</a></li>";
                      }else{
                        $btns = "btn-danger";
                        $acts = "Stoped";
                        $lis = "<li><a href='php/action.php?usr_adm=".$users_id."&acts=10'>Admin</a></li>";
                      }

                  ?>
                <tr>
                  <td>
                      <img class="img-circle img-sm" src="dist/img/<?php echo $row['profile']; ?>" alt="<?php echo $row['profile']; ?>">
                      <b>
                        &nbsp;&nbsp;<?php echo $row['user_name']; ?>
                      </b><!-- /.username -->
                    </td>
                  
                  <td><i class="fa fa-phone text-navy"></i> <?php echo $row['user_phone']; ?>,&nbsp;&nbsp;
                    <i class="fa fa-envelope text-navy"></i> <?php echo $row['user_email']; ?></td>
                  
                  <td><b><?php echo $row['post_name']; ?></b></td>
                  
          
                  
                  <td>
                    <?php if ($rows['act_user'] == 1) { ?>
                  <div class="btn-group">
                    <button type="button" class="btn <?php echo $btn; ?>"><?php echo $act; ?></button>
                    <button type="button" class="btn <?php echo $btn; ?> dropdown-toggle" data-toggle="dropdown">
                      <span class="caret"></span>
                      <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <ul class="dropdown-menu" role="menu">
                      <li><center><b>Change Status</b></center></li>
                      <li class="divider"></li>
                      <?php echo $li; ?>
                    </ul>
                  </div>
                    <?php } ?>
                  </td>
                  <!--the admin or worker session-->
                   <td>
                    <?php if ($rows['act_level'] == 1) { ?>
                  <div class="btn-group">
                    <button type="button" class="btn <?php echo $btns; ?>"><?php echo $acts; ?></button>
                    <button type="button" class="btn <?php echo $btns; ?> dropdown-toggle" data-toggle="dropdown">
                      <span class="caret"></span>
                      <span class="sr-only">Toggle Dropdown</span>
                    </button>
                    <ul class="dropdown-menu" role="menu">
                      <li><center><b>Change Place</b></center></li>
                      <li class="divider"></li>
                      <?php echo $lis; ?>
                      
                    </ul>
                  </div>
                    <?php } ?>
                  </td>

                </tr>
                  <?php }} ?><br>
                </tbody>
                <tr>

                  <th colspan="5">TMI User List</th>
                </tr>
              </table><br>
              </div>
              <!-- /.box-body -->
            </div>
            <!-- /.box -->
          </div>
        </div>
      </div>
    </section>