    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="dist/img/<?php echo $row_user['profile']; ?>" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $row_user['user_name']; ?></h3>

              <p class="text-muted text-center"><?php echo $row_user['user_name']; ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item"><span class="glyphicon glyphicon-envelope"></span>
                  <b><?php echo $row_user['user_email']; ?></b>
                </li>
                <li class="list-group-item">
                  <span class="glyphicon glyphicon-earphone"></span>
                  <b><?php echo $row_user['user_phone']; ?></b>
                </li>
                <li class="list-group-item">
                  <span class="glyphicon glyphicon-calendar"></span>
                  <b>Registered on <?php echo date_format($date, "d M, Y"); ?></b>
                </li>
              </ul>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="#settings" data-toggle="tab">Settings</a></li>
            </ul>
            <div class="tab-content">
              <?php include('setting.php'); ?>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->