    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
        
        <section class="col-xs-10 ">

          <div class="box box-success">
            <div class="box-header">
              <i class="fa fa-th"></i>
              <h3 class="box-title">Models</h3>
             <?php if ($rows['act_model'] == 1) { ?>
              <span style="margin-left: 80%"><a href="home.php?ADD=Model" class="btn-sm bg-blue">
                    <i class="fa fa-edit"></i> New</a></span>
                    <?php }?>
            </div>

          <?php
          $sql = "SELECT * FROM about_teen";
          $result = $conn->query($sql);
          $row = $result->fetch_assoc();
          // Working on Satus of each

          //Short message "Status message"
          if ($row['msg_status'] == 0) {
            $text_1 = "text-red";
            $status_1 = "Invisible";
            $title_1 = "Display it";
            $texter_1 = "text-blue";
            $todo_1 = 1;
          } else {
            $text_1 = "text-blue";
            $status_1 = "Visible";
            $title_1 = "Undisplay it";
            $texter_1 = "text-red";
            $todo_1 = 0;
          }
          
          //What we do
          if ($row['we_do_status'] == 0) {
            $text_3 = "text-red";
            $status_3 = "Invisible";
            $title_3 = "Display it";
            $texter_3 = "text-blue";
            $todo_3 = 1;
          } else {
            $text_3 = "text-blue";
            $status_3 = "Visible";
            $title_3 = "Undisplay it";
            $texter_3 = "text-red";
            $todo_3 = 0;
          }
          //Our vision
          if ($row['vision_status'] == 0) {
            $text_4 = "text-red";
            $status_4 = "Invisible";
            $title_4 = "Display it";
            $texter_4 = "text-blue";
            $todo_4 = 1;
          } else {
            $text_4 = "text-blue";
            $status_4 = "Visible";
            $title_4 = "Undisplay it";
            $texter_4 = "text-red";
            $todo_4 = 0;
          }
          //Our mission
          if ($row['mission_status'] == 0) {
            $text_5 = "text-red";
            $status_5 = "Invisible";
            $title_5 = "Display it";
            $texter_5 = "text-blue";
            $todo_5 = 1;
          } else {
            $text_5 = "text-blue";
            $status_5 = "Visible";
            $title_5 = "Undisplay it";
            $texter_5 = "text-red";
            $todo_5 = 0;
          }
          
          ?>


          <div class="box box-info">
            
            <div class="box-body">

             <!-- chat item --><!-- Teen Definition -->
              
              <div class="item">
                
              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <?php if ($row_post['act_about'] == 1) { ?>
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="php/action.php?abt_st=we_do_status&todo=<?php echo $todo_3; ?>" class="btn btn-default btn-sm" title="<?php echo $title_3; ?>"><i class="fa fa-square <?php echo $texter_3; ?>"></i>
                  </a>
                  <a href="home.php?ADD=Model&update=what_we_do" class="btn btn-default btn-sm" title="Edit"><i class="glyphicon glyphicon-edit text-blue"></i></a>
                </div>
                <?php } ?>
              </div>

                <!-- <i class="fa fa-exclamation-triangle <?php// echo $text_3; ?>"> Status:</i> <b><?php// echo $status_3; ?></b> -->
                <p class="message"><a href="#" class="name">
                    <h4>What we do</h4>
                  </a></p>
                <p class="message">
                  <?php echo $row['what_we_do']; ?>
                </p>

              </div>
              <br/>
              <!-- / .chat item -->

             <!-- chat item --><!-- Teen Vision -->
              
              <div class="item">
                
              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <?php if ($row_post['act_about'] == 1) { ?>
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="php/action.php?abt_st=vision_status&todo=<?php echo $todo_4; ?>" class="btn btn-default btn-sm" title="<?php echo $title_4; ?>"><i class="fa fa-square <?php echo $texter_4; ?>"></i>
                  </a>
                  <a href="home.php?ADD=Model" class="btn btn-default btn-sm" title="Edit"><i class="glyphicon glyphicon-edit text-blue"></i></a>
                </div>
                <?php } ?>
              </div>

                <!-- <i class="fa fa-exclamation-triangle <?php// echo $text_4; ?>"> Status:</i> <b><?php// echo $status_4; ?></b> -->
                <p class="message"><a href="#" class="name">
                   <h4> Our Vision</h4>
                  </a></p>
                <p class="message">
                  <?php echo $row['our_vision']; ?>
                </p>

              </div>
              <br/>
              <!-- / .chat item -->

             <!-- chat item --><!-- Teen our_mission -->
              
              <div class="item">
                
              <div class="box-tools pull-right" data-toggle="tooltip" title="Status">
                <?php if ($row_post['act_about'] == 1) { ?>
                <div class="btn-group" data-toggle="btn-toggle">
                  <a href="php/action.php?abt_st=mission_status&todo=<?php echo $todo_5; ?>" class="btn btn-default btn-sm" title="<?php echo $title_5; ?>"><i class="fa fa-square <?php echo $texter_5; ?>"></i>
                  </a>
                  <a href="home.php?ADD=Model" class="btn btn-default btn-sm" title="Edit"><i class="glyphicon glyphicon-edit text-blue"></i></a>
                </div>
                <?php } ?>
              </div>

                <!-- <i class="fa fa-exclamation-triangle <?php //echo $text_5; ?>"> Status:</i> <b><?php// echo $status_5; ?></b> -->
                <p class="message"><a href="#" class="name">
                  <h4>  Our Mission </h4>
                  </a></p>
                <p class="message">
                  <?php echo $row['our_mission']; ?>
                </p>

              </div>
              <br/>
              <!-- / .chat item -->

            
            </div>
          </div>           
        </div>
      </div>
    </section>
  </div>