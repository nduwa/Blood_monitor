
<?php
            $sql = "SELECT * FROM bloodstore INNER JOIN blood_type ON bloodstore.bl_type_id = blood_type.type_id WHERE username = '" . $row_user['user_title']. "'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- col-md-3 -->
        <?php //include('mail_aside.php'); ?>
        <!-- /.col -->
        <div class="col-md-6">
          <table class="table table-condensed">
                <tr>
                  <th>#</th>
                  <th>Blood ID</th>
                  <th>Blood Type</th>
                  <th>Quantity</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()) {
                  if ($row['utility_id'] == 1) {
                    $qty = $row['bl_qntes']; 
                ?>
                <tr>
                  <td><a href="php/action.php?pudel=<?php echo $row['bl_id']; ?>" class="btn-sm bg-red">
                    <i class="fa fa-trash"></i></a></td>
                    <td>
                    <?php echo $row['type_code']; ?></td>
                    <td>
                    <?php echo $row['type_name']; ?></td>
                    <td><b style="color: green;">
                    <?php echo $row['bl_qntes']; ?></b></td>
                </tr>
                <tr><td colspan="5"></td></tr>
                <?php }}} ?>
              </table>
        </div>
                <?php
    if (isset($_REQUEST['edit'])) {
      $label = "Update Post:";
      $act = "update_request";
      $name = $_REQUEST['edit'];
      $id = $_REQUEST['id']; 
    }
    else {
      $label = "New Blood type:";
      $act = "new_type";
      $name = "";
      $id = ""; 
    }
    ?>
    <?php
    $email = $_REQUEST['id'];
    $prev = $email - 1;
    $next = $email + 1;

    $sql = "SELECT * FROM bloodrequest INNER JOIN teen_posters ON bloodrequest.served_quantity=teen_posters.post_id INNER JOIN blood_type ON bloodrequest.bl_type=blood_type.type_id WHERE bl_rid = '$email'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $id = $row['bl_rid'];
    $sqls = "SELECT * FROM blood_type";
    $results = $conn->query($sqls);
    $rows = $results->fetch_assoc();

    ?>
        <div class="col-md-5">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">View the Request</h3>

              <div class="box-tools pull-right">
                <a href="php/action.php?readmail=<?php echo $prev; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="Previous"><i class="fa fa-chevron-left"></i></a>
                <a href="php/action.php?readmail=<?php echo $next; ?>" class="btn btn-box-tool" data-toggle="tooltip" title="Next"><i class="fa fa-chevron-right"></i></a>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-read-info">
                
                <h5>From: <?php echo $row['bl_username']." &nbsp;&nbsp;&nbsp;&nbsp; Work in  ".$row['post_name']; ?> 
                  <span class="mailbox-read-time pull-right">
                    <?php
                    $time =  $row['bl_date'];
                    $d = strtotime($time);
                        echo date("d M.Y h:i:A", $d); ?>
                          
                  </span></h5>
              </div>
              <!-- /.mailbox-read-info -->
              <div class="mailbox-controls with-border text-center">
                <form action="php/action.php" method="post" enctype="multipart/form-data">
                <div class="row">
                  <div class="col-md-2">
                    <input  class="form-control" name="bl_user_title" id="name" type="hidden" value="<?php echo $row['served_quantity']; ?>"  >

                    <input  class="form-control" name="user_title" id="name" type="hidden" value="<?php echo $row_user['user_title']; ?>" >

                        <label>Blood Type</label><br>
                        <label style="color: green;"><?php echo $row['type_name']; ?></label>

                        <input  class="form-control" name="blood_id" id="name" type="hidden" value="<?php echo $row['type_id']; ?>" >

                        <input  class="form-control" name="bl_id" id="name" type="hidden" value="<?php echo $row['type_id']; ?>" >
                      </div>
                      <div class="col-md-9">
                        <label>requested quantity</label>
                        <input  class="form-control" name="userid" id="name" type="text" value="<?php echo $row['bl_quantity']; ?>" disabled="disabled" >
                      </div>
                </div>
                <div class="row">
                      <div class="col-md-7">
                        <label>Message</label>
                        <p><?php echo $row['bl_comment']; ?></p>
                      </div>
                   <div class="col-md-4"></div>
                </div>
                <?php  if ($row['bl_status'] == 0) { ?>
                <div class="row">
                  <div class="col-md-2"></div>
                  
                    <div class="col-md-9">
                          <label>Served quantity</label>
                          <input  class="form-control" name="serve" id="name"  min="0" type="number" >
                      </div>
                </div>                   
              </div>
              <!-- /.mailbox-controls -->
              <!-- /.mailbox-read-message -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <center><button  name = "update_request" class="btn btn-success btn-block">Save</button></center> 
            </div>
          <?php } ?>

            </form>
            <!-- /.box-footer -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->