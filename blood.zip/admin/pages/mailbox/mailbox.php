    <?php
    $status = 2;
    $user = $row_user['user_id'];
    $sql = "SELECT * FROM bloodrequest INNER JOIN teen_posters ON bloodrequest.served_quantity=teen_posters.post_id INNER JOIN blood_type ON bloodrequest.bl_type=blood_type.type_id ORDER BY bl_rid DESC limit 6";
    $result = $conn->query($sql);
    $sqls = "SELECT * FROM blood_type";
    $results = $conn->query($sqls);
    $sqlse = "SELECT * FROM teen_posters";
    $resultse = $conn->query($sqlse);
    ?>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- col-md-3 -->
        <?php //include('mail_aside.php'); ?>
        <!-- /. col-md-3 -->
        <div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Inbox</h3>

              <!--
              <div class="box-tools pull-right">
                <div class="has-feedback">
                  <input type="text" class="form-control input-sm" placeholder="Search Mail">
                  <span class="glyphicon glyphicon-search form-control-feedback"></span>
                </div>
              </div> -->
              <!-- /.box-tools -->
            </div>
            
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-controls">
                
                <!-- /.pull-right -->
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>From</th>
                      <th>Blood request</th>
                      <th>Date</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    if ($result->num_rows > 0) { 
                      $rows = $results->fetch_assoc();
                      while($row = $result->fetch_assoc()){ 
                        if ($row['bl_user_title'] == $row_user['user_title'])  {
                        ?>
                  <tr>
                    
                    <td class="mailbox-name"><a href="home.php?view=readmail&edit=<?php echo $row['bl_username']; ?>&id=<?php echo $row['bl_rid']; ?>"><?php echo $row['post_name']." From ".$row['bl_username']; ?></a></td>
                    <td class="mailbox-subject"><b> &nbsp;<?php echo $row['type_name']; ?>
                    </td>
                    <td class="mailbox-date">
                      <?php 
                        $d = strtotime($row['bl_date']);
                        echo date("l, d M,Y", $d);
                      ?></td>
                      <?php if ($row['bl_status'] == 0) { 
                  $status = "NEW"; $add_st = "fa-toggle-off text-blue";  }
                else { 
                  $status = "SERVED"; $add_st = "fa-check text-green";  } ?>
                    
                  <td>
                      <i class="fa <?php echo $add_st; ?>"font-color="green"> <?php echo $status; ?></i> 
                  </td>
                  </tr>
                    <?php }} }
                    else { ?>
                  <tr>
                    <td colspan="4" align="center">No blood request!</td>
                  </tr>
                    <?php } ?>
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
