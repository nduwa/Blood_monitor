
<?php
require "../php/connection.php";

if (!empty($_GET['placeId'])) {
	/*$sql_query = "SELECT * FROM tbl_regions 
	JOIN teen_posters  ON (tbl_regions.region_id = teen_posters.region_id)
	WHERE teen_posters.	post_id = '". htmlspecialchars($_GET["placeId"])."' ";*/

$sql_query = "SELECT blood_type.type_id, blood_type.type_name,blood_type.type_code
              FROM blood_type ";
	
$result = mysqli_query($conn,$sql_query) or die("error ".mysqli_error($conn));

$hospital = array();

while($row = mysqli_fetch_assoc($result)){
//$row["Image"] = base64_encode($row["Image"]);
$hospital[] = $row;
}
echo json_encode($hospital);
//echo json_encode(array('students' => $student)); this returns a //student object named students

 mysqli_close($conn);

}
//$a = "123";
//echo md5($a);
/*$sql_query = "SELECT * FROM teen_posters 
	          JOIN tbl_regions ON (tbl_regions.region_id = teen_posters.region_id)
	         WHERE teen_posters.region_id = '". htmlspecialchars($_GET["placeId"])."'";*/
?> 

