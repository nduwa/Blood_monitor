<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<div class="wrapper">

<?php
require "db_connection.php";

if (!empty($_GET['studentId'])) {
	$sql_query = "SELECT * FROM student
	JOIN details ON (student.Student_Id = details.Student_Id)
	WHERE student.Student_Id = '". htmlspecialchars($_GET["studentId"])."' ";


	$result = mysqli_query($conn,$sql_query) or die("error".mysqli_error($conn));
	$row = mysqli_fetch_assoc($result);
	$cnt = count($row);

//if no student details found then create
    if($cnt >1){
		echo '
		<h1>Student Details: <br>'.$row["Name"].'<br> </h1>
		<hr>
		<section>
		<div id="addDiv">
		<label> <br>'.$row["DoB"].'<br> <label/>
		<label> <br>'.$row["Gender"].'<br> <label/>
		<p> <br>'.$row["Details"].'<br> <p/>

		</div>  
		<div id="imgDiv">
		<label> 
			<img width="80%" height="60%" src="data:image/jpeg;base64, '.base64_encode($row["Image"]).'" />
		<label/>  
		</div>
		</section>
		';
	}
	else{
	$sql_query = "SELECT * FROM student WHERE Student_Id = '". htmlspecialchars($_GET["studentId"])."' ";
	$result = mysqli_query($conn,$sql_query) or die("error".mysqli_error($conn));
	$row = mysqli_fetch_assoc($result);
			echo '
			<form action="/StudentApp/CreateStudentDetails.php">
			<input type="hidden" name="Student_Id" value="'.$row["Student_Id"].'">
				<h1>Create Details for student: '.$row["Name"].'<br></h1>
				<textarea name="Details" cols="53" rows="6"></textarea><br/>				
				<input type="submit" value="Create">
			</form>';
	
	}
}
$conn->close();

echo '
<a href="studentDetailsJson.php?studentId='. htmlspecialchars($_GET["studentId"]).'"> Return sinlge Student Json Object<a/>
</label> 
';
?> 
<hr>
By Valentin's Student- to 4Th year Computer Science

</div>
</body>
</html>
