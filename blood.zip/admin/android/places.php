<?php
require "../php/connection.php";

$room_type_id = 1;
$room_price = 500;
$format = "json";

$sql = "SELECT *FROM tbl_regions";
  	$result = $conn->query($sql);
  	while($e = mysqli_fetch_assoc($result)){
        		$output[]= $e; 
  			}
  	print(json_encode($output)); 
  	$conn->close();
	
?>

